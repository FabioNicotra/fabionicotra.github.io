from dataclasses import dataclass
from typing import Dict, Any, SupportsFloat
import numpy as np
import pandas as pd
from numpy.typing import NDArray

from ..core.newton_polynomial import NewtonPolynomial


@dataclass(frozen=True)
class DDResult:
    method_name: str
    polynomial: NewtonPolynomial
    x: NDArray[np.float64]
    y: NDArray[np.float64]
    divided_diff_table: NDArray[np.float64]

    def add_node(self, x_new: SupportsFloat, y_new: SupportsFloat) -> 'DDResult':
        x_new = float(x_new)
        y_new = float(y_new)
        if x_new in self.x:
            raise ValueError("New node x must be distinct from existing nodes.")
        m = len(self.x)
        new_F = np.zeros((m + 1, m + 1))
        new_F[:m, :m] = self.divided_diff_table
        new_F[m, 0] = y_new
        for j in range(1, m + 1):
            new_F[m, j] = (new_F[m, j - 1] - new_F[m - 1, j - 1]) / (x_new - self.x[m - j])
        new_x = np.append(self.x, x_new)
        new_y = np.append(self.y, y_new)
        return DDResult(
            method_name=self.method_name,
            polynomial=NewtonPolynomial(nodes=new_x[:-1], coeffs=np.diag(new_F)),
            x=new_x,
            y=new_y,
            divided_diff_table=new_F,
        )

    def to_df(self) -> pd.DataFrame:
        n = len(self.x)
        data: Dict[str, Any] = {"x_i": self.x, "F_{i,0}": self.y}
        for j in range(1, n):
            data[f"F_{{i,{j}}}"] = [
                self.divided_diff_table[i, j] if j <= i else float("nan") for i in range(n)
            ]
        return pd.DataFrame(data)


class DividedDifferences:
    def __init__(self, x: NDArray[np.float64], y: NDArray[np.float64]):
        self.x = x
        self.y = y
        if len(self.x) != len(self.y):
            raise ValueError("Input arrays x and y must have the same length.")
        self.F = self._build_table(self.x, self.y)

    @staticmethod
    def _build_table(x: NDArray[np.float64], y: NDArray[np.float64]) -> NDArray[np.float64]:
        n = len(x)
        F = np.zeros((n, n))
        F[:, 0] = y
        for i in range(1, n):
            for j in range(1, i + 1):
                F[i, j] = (F[i, j - 1] - F[i - 1, j - 1]) / (x[i] - x[i - j])
        return F

    @property
    def x(self) -> NDArray[np.float64]:
        return self._x

    @x.setter
    def x(self, value: NDArray[np.float64]) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 1:
            raise ValueError("x must be a 1-D array.")
        if len(np.unique(value)) != len(value):
            raise ValueError("Interpolation nodes x must be distinct.")
        self._x = value

    @property
    def y(self) -> NDArray[np.float64]:
        return self._y

    @y.setter
    def y(self, value: NDArray[np.float64]) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 1:
            raise ValueError("y must be a 1-D array.")
        self._y = value

    def add_node(self, x_new: SupportsFloat, y_new: SupportsFloat) -> None:
        x_new = float(x_new)
        y_new = float(y_new)
        if x_new in self.x:
            raise ValueError("New node x must be distinct from existing nodes.")
        m = len(self.x)
        new_F = np.zeros((m + 1, m + 1))
        new_F[:m, :m] = self.F
        new_F[m, 0] = y_new
        for j in range(1, m + 1):
            new_F[m, j] = (new_F[m, j - 1] - new_F[m - 1, j - 1]) / (x_new - self.x[m - j])
        self.x = np.append(self.x, x_new)
        self.y = np.append(self.y, y_new)
        self.F = new_F

    def interpolate(self) -> 'DDResult':
        return DDResult(
            method_name="Newton Divided Differences",
            polynomial=NewtonPolynomial(nodes=self.x[:-1], coeffs=np.diag(self.F)),
            x=self.x,
            y=self.y,
            divided_diff_table=self.F,
        )
