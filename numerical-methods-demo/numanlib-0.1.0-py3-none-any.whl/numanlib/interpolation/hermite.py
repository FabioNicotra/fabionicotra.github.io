from dataclasses import dataclass
from typing import Dict, Any, SupportsFloat
import numpy as np
import pandas as pd
from numpy.typing import NDArray

from ..core.newton_polynomial import NewtonPolynomial


@dataclass(frozen=True)
class HermiteResult:
    method_name: str
    polynomial: NewtonPolynomial
    x: NDArray[np.float64]
    y: NDArray[np.float64]
    dy: NDArray[np.float64]
    z: NDArray[np.float64]
    Q_table: NDArray[np.float64]

    def add_node(self, x_new: SupportsFloat, y_new: SupportsFloat, dy_new: SupportsFloat) -> 'HermiteResult':
        x_new = float(x_new)
        y_new = float(y_new)
        dy_new = float(dy_new)
        if x_new in self.x:
            raise ValueError("New node x must be distinct from existing nodes.")
        m = len(self.z)
        new_z = np.append(self.z, [x_new, x_new])
        new_Q = np.zeros((m + 2, m + 2))
        new_Q[:m, :m] = self.Q_table
        new_Q[m, 0] = y_new
        new_Q[m + 1, 0] = y_new
        new_Q[m, 1] = (y_new - self.Q_table[m - 1, 0]) / (x_new - self.z[m - 1])
        new_Q[m + 1, 1] = dy_new
        for j in range(2, m + 2):
            if j <= m:
                new_Q[m, j] = (new_Q[m, j - 1] - new_Q[m - 1, j - 1]) / (x_new - new_z[m - j])
            new_Q[m + 1, j] = (new_Q[m + 1, j - 1] - new_Q[m, j - 1]) / (x_new - new_z[m + 1 - j])
        new_x = np.append(self.x, x_new)
        new_y = np.append(self.y, y_new)
        new_dy = np.append(self.dy, dy_new)
        return HermiteResult(
            method_name=self.method_name,
            polynomial=NewtonPolynomial(nodes=new_z[:-1], coeffs=np.diag(new_Q)),
            x=new_x,
            y=new_y,
            dy=new_dy,
            z=new_z,
            Q_table=new_Q,
        )

    def to_df(self) -> pd.DataFrame:
        m = len(self.z)
        data: Dict[str, Any] = {"z_i": self.z, "f(z_i)": self.Q_table[:, 0]}
        for j in range(1, m):
            data[f"Q_{{i,{j}}}"] = [
                self.Q_table[i, j] if j <= i else float("nan") for i in range(m)
            ]
        return pd.DataFrame(data)


class Hermite:
    def __init__(self, x: NDArray[np.float64], y: NDArray[np.float64], dy: NDArray[np.float64]):
        self.x = x
        self.y = y
        self.dy = dy
        if not (len(self.x) == len(self.y) == len(self.dy)):
            raise ValueError("Input arrays x, y, and dy must have the same length.")
        self.z, self.Q = self._build_table(self.x, self.y, self.dy)

    @staticmethod
    def _build_table(
        x: NDArray[np.float64],
        y: NDArray[np.float64],
        dy: NDArray[np.float64],
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        n = len(x)
        m = 2 * n
        z = np.zeros(m)
        Q = np.zeros((m, m))
        for i in range(n):
            z[2 * i] = x[i]
            z[2 * i + 1] = x[i]
            Q[2 * i, 0] = y[i]
            Q[2 * i + 1, 0] = y[i]
            Q[2 * i + 1, 1] = dy[i]
            if i > 0:
                Q[2 * i, 1] = (Q[2 * i, 0] - Q[2 * i - 1, 0]) / (z[2 * i] - z[2 * i - 1])
        for j in range(2, m):
            for i in range(j, m):
                Q[i, j] = (Q[i, j - 1] - Q[i - 1, j - 1]) / (z[i] - z[i - j])
        return z, Q

    @property
    def x(self) -> NDArray[np.float64]:
        return self._x

    @x.setter
    def x(self, value: NDArray[np.float64]) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 1:
            raise ValueError("x must be a 1-D array.")
        if len(np.unique(value)) != len(value):
            raise ValueError("Interpolation nodes x must be distinct.")
        self._x = value

    @property
    def y(self) -> NDArray[np.float64]:
        return self._y

    @y.setter
    def y(self, value: NDArray[np.float64]) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 1:
            raise ValueError("y must be a 1-D array.")
        self._y = value

    @property
    def dy(self) -> NDArray[np.float64]:
        return self._dy

    @dy.setter
    def dy(self, value: NDArray[np.float64]) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 1:
            raise ValueError("dy must be a 1-D array.")
        self._dy = value

    def add_node(self, x_new: SupportsFloat, y_new: SupportsFloat, dy_new: SupportsFloat) -> None:
        x_new = float(x_new)
        y_new = float(y_new)
        dy_new = float(dy_new)
        if x_new in self.x:
            raise ValueError("New node x must be distinct from existing nodes.")
        m = len(self.z)
        new_z = np.append(self.z, [x_new, x_new])
        new_Q = np.zeros((m + 2, m + 2))
        new_Q[:m, :m] = self.Q
        new_Q[m, 0] = y_new
        new_Q[m + 1, 0] = y_new
        new_Q[m, 1] = (y_new - self.Q[m - 1, 0]) / (x_new - self.z[m - 1])
        new_Q[m + 1, 1] = dy_new
        for j in range(2, m + 2):
            if j <= m:
                new_Q[m, j] = (new_Q[m, j - 1] - new_Q[m - 1, j - 1]) / (x_new - new_z[m - j])
            new_Q[m + 1, j] = (new_Q[m + 1, j - 1] - new_Q[m, j - 1]) / (x_new - new_z[m + 1 - j])
        self.x = np.append(self.x, x_new)
        self.y = np.append(self.y, y_new)
        self.dy = np.append(self.dy, dy_new)
        self.z = new_z
        self.Q = new_Q

    def interpolate(self) -> 'HermiteResult':
        return HermiteResult(
            method_name="Hermite",
            polynomial=NewtonPolynomial(nodes=self.z[:-1], coeffs=np.diag(self.Q)),
            x=self.x,
            y=self.y,
            dy=self.dy,
            z=self.z,
            Q_table=self.Q,
        )
