from dataclasses import dataclass
import numpy as np
import pandas as pd
from numpy.typing import NDArray
from typing import Optional

from ..linear_systems import CroutTridiagonalSolver

_NATURAL = "Natural Cubic Spline"
_CLAMPED = "Clamped Cubic Spline"


@dataclass(frozen=True)
class CubicSplineResult:
    method_name: str
    x: NDArray[np.float64]   # n+1 breakpoints
    y: NDArray[np.float64]   # n+1 function values
    a: NDArray[np.float64]   # n values: a_j = y_j
    b: NDArray[np.float64]   # n values: linear coefficients
    c: NDArray[np.float64]   # n values: quadratic coefficients (c_0,...,c_{n-1})
    d: NDArray[np.float64]   # n values: cubic coefficients

    @property
    def polynomial(self):
        return self

    def __call__(self, x_eval):
        scalar = np.isscalar(x_eval)
        x_eval = np.atleast_1d(np.asarray(x_eval, dtype=float))
        n = len(self.a)
        j = np.clip(np.searchsorted(self.x[1:-1], x_eval), 0, n - 1)
        t = x_eval - self.x[j]
        result = self.a[j] + self.b[j]*t + self.c[j]*t**2 + self.d[j]*t**3
        return float(result[0]) if scalar else result

    def to_df(self) -> pd.DataFrame:
        return pd.DataFrame({
            "j": range(len(self.a)),
            "a_j": self.a,
            "b_j": self.b,
            "c_j": self.c,
            "d_j": self.d,
        }).set_index("j")


class CubicSpline:
    def __init__(
        self,
        x: NDArray[np.float64],
        y: NDArray[np.float64],
        fp0: Optional[float] = None,
        fpn: Optional[float] = None,
    ):
        self.x = x
        self.y = y
        if (fp0 is None) != (fpn is None):
            raise ValueError(
                "Provide both fp0 and fpn for a clamped spline, or neither for a natural spline."
            )
        self._fp0 = None if fp0 is None else float(fp0)
        self._fpn = None if fpn is None else float(fpn)

    @property
    def x(self) -> NDArray[np.float64]:
        return self._x

    @x.setter
    def x(self, value) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 1:
            raise ValueError("x must be a 1-D array.")
        if len(value) < 3:
            raise ValueError("Cubic spline interpolation requires at least 3 data points.")
        if not np.all(np.diff(value) > 0):
            raise ValueError("x must be strictly increasing.")
        self._x = value

    @property
    def y(self) -> NDArray[np.float64]:
        return self._y

    @y.setter
    def y(self, value) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 1:
            raise ValueError("y must be a 1-D array.")
        self._y = value

    def interpolate(self) -> 'CubicSplineResult':
        x, y = self.x, self.y
        n = len(x) - 1
        a = y.copy()
        h = np.diff(x)

        if self._fp0 is None:
            c_full = _solve_natural(a, h, n)
            method_name = _NATURAL
        else:
            c_full = _solve_clamped(a, h, n, self._fp0, self._fpn)
            method_name = _CLAMPED

        b = (a[1:] - a[:-1]) / h - h * (c_full[1:] + 2 * c_full[:-1]) / 3
        d = (c_full[1:] - c_full[:-1]) / (3 * h)

        return CubicSplineResult(
            method_name=method_name,
            x=x,
            y=y,
            a=a[:-1],
            b=b,
            c=c_full[:-1],
            d=d,
        )


def _solve_natural(a: NDArray, h: NDArray, n: int) -> NDArray:
    alpha = 3 * ((a[2:] - a[1:-1]) / h[1:] - (a[1:-1] - a[:-2]) / h[:-1])
    main = 2 * (h[:-1] + h[1:])
    c_full = np.zeros(n + 1)
    if len(alpha) == 1:
        c_full[1] = alpha[0] / main[0]
        return c_full
    off = h[1:-1]
    A = np.diag(main) + np.diag(off, 1) + np.diag(off, -1)
    result = CroutTridiagonalSolver(A=A, b=alpha).solve()
    if not result.solved:
        raise ValueError(f"Failed to solve spline system: {result.error_msg}")
    c_full[1:-1] = result.solution
    return c_full


def _solve_clamped(a: NDArray, h: NDArray, n: int, fp0: float, fpn: float) -> NDArray:
    alpha = np.empty(n + 1)
    alpha[0] = 3 * (a[1] - a[0]) / h[0] - 3 * fp0
    alpha[1:-1] = 3 * ((a[2:] - a[1:-1]) / h[1:] - (a[1:-1] - a[:-2]) / h[:-1])
    alpha[n] = 3 * fpn - 3 * (a[n] - a[n - 1]) / h[n - 1]
    main = np.empty(n + 1)
    main[0] = 2 * h[0]
    main[1:-1] = 2 * (h[:-1] + h[1:])
    main[n] = 2 * h[n - 1]
    A = np.diag(main) + np.diag(h, 1) + np.diag(h, -1)
    result = CroutTridiagonalSolver(A=A, b=alpha).solve()
    if not result.solved:
        raise ValueError(f"Failed to solve spline system: {result.error_msg}")
    return result.solution
