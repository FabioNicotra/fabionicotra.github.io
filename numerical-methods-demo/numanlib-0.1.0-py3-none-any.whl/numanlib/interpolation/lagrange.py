from dataclasses import dataclass, field
from typing import Dict, Any
import numpy as np
from numpy.typing import NDArray

from ..core.polynomial import Polynomial


@dataclass(frozen=True)
class LagrangeResult:
    method_name: str
    polynomial: Polynomial
    x: NDArray[np.float64]
    y: NDArray[np.float64]
    metadata: Dict[str, Any] = field(default_factory=dict)


def lagrange(x: NDArray[np.float64], y: NDArray[np.float64]) -> 'LagrangeResult':
    if x.ndim != 1 or y.ndim != 1:
        raise ValueError("Input arrays x and y must be one-dimensional.")
    if len(x) != len(y):
        raise ValueError("Input arrays x and y must have the same length.")
    if len(np.unique(x)) != len(x):
        raise ValueError("Interpolation nodes x must be distinct.")
    n = len(x)
    # Compute the Lagrange basis polynomials
    basis_polynomials = []
    for k in range(n):
        num = Polynomial.from_roots(x[i] for i in range(n) if i != k)
        den = num(x[k])
        L_k = num / den
        basis_polynomials.append(L_k)
    # Compute the interpolating polynomial
    interpolating_polynomial = sum(y[k] * basis_polynomials[k] for k in range(n))
    return LagrangeResult(
        method_name = "Lagrange",
        polynomial = interpolating_polynomial,
        x = x,
        y = y,
        metadata = {
            "basis_polynomials": basis_polynomials
        }
    )