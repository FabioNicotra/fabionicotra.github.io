from dataclasses import dataclass
from typing import Dict, Any, SupportsFloat
import numpy as np
import pandas as pd
from numpy.typing import NDArray


@dataclass(frozen=True)
class NevilleResult:
    value: float
    x_eval: float
    x: NDArray[np.float64]
    y: NDArray[np.float64]
    Q_table: NDArray[np.float64]
    method_name: str = "Neville"

    def add_node(self, x_new: SupportsFloat, y_new: SupportsFloat) -> 'NevilleResult':
        x_new = float(x_new)
        y_new = float(y_new)
        if x_new in self.x:
            raise ValueError("New node x must be distinct from existing nodes.")
        n = len(self.x)
        new_x = np.append(self.x, x_new)
        new_y = np.append(self.y, y_new)
        new_Q = np.zeros((n + 1, n + 1))
        new_Q[:n, :n] = self.Q_table
        new_Q[n, 0] = y_new
        for j in range(1, n + 1):
            new_Q[n, j] = (
                (self.x_eval - new_x[n - j]) * new_Q[n, j - 1]
                - (self.x_eval - x_new) * self.Q_table[n - 1, j - 1]
            ) / (x_new - new_x[n - j])
        return NevilleResult(
            value=new_Q[n, n],
            x_eval=self.x_eval,
            x=new_x,
            y=new_y,
            Q_table=new_Q,
        )

    def to_df(self) -> pd.DataFrame:
        n = len(self.x)
        data: Dict[str, Any] = {"x_i": self.x, "Q_{i,0}": self.y}
        for j in range(1, n):
            data[f"Q_{{i,{j}}}"] = [
                self.Q_table[i, j] if j <= i else float("nan") for i in range(n)
            ]
        return pd.DataFrame(data)

class Neville:
    def __init__(self, x: NDArray[np.float64], y: NDArray[np.float64]):
        self.x = x
        self.y = y
        if len(self.x) != len(self.y):
            raise ValueError("x and y must have the same length.")

    @property
    def x(self) -> NDArray[np.float64]:
        return self._x

    @x.setter
    def x(self, value: NDArray[np.float64]) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 1:
            raise ValueError("x must be a 1-D array.")
        if len(np.unique(value)) != len(value):
            raise ValueError("Interpolation nodes x must be distinct.")
        self._x = value

    @property
    def y(self) -> NDArray[np.float64]:
        return self._y

    @y.setter
    def y(self, value: NDArray[np.float64]) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 1:
            raise ValueError("y must be a 1-D array.")
        self._y = value

    def add_node(self, x_new: SupportsFloat, y_new: SupportsFloat) -> None:
        x_new = float(x_new)
        y_new = float(y_new)
        if x_new in self.x:
            raise ValueError("New node x must be distinct from existing nodes.")
        self.x = np.append(self.x, x_new)
        self.y = np.append(self.y, y_new)

    def evaluate(self, x_eval: SupportsFloat) -> 'NevilleResult':
        try:
            x_eval = float(x_eval)
        except (TypeError, ValueError):
            raise TypeError("x_eval must be a numeric value.")

        n = len(self.x)
        Q_table = np.zeros((n, n))
        Q_table[:, 0] = self.y
        for i in range(1, n):
            for j in range(1, i + 1):
                Q_table[i, j] = (
                    (x_eval - self.x[i - j]) * Q_table[i, j - 1]
                    - (x_eval - self.x[i]) * Q_table[i - 1, j - 1]
                ) / (self.x[i] - self.x[i - j])

        return NevilleResult(
            value=Q_table[n - 1, n - 1],
            x_eval=x_eval,
            x=self.x,
            y=self.y,
            Q_table=Q_table,
        )
