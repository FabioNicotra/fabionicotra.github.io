from . import root_finding
from . import interpolation
from . import linear_systems
from . import differentiation

import matplotlib.pyplot as plt

plt.ion()
