from .polynomial import Polynomial
from .newton_polynomial import NewtonPolynomial