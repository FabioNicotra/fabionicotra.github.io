"""Text helpers shared by the stencil-style result objects
(FiniteDifferenceResult, NewtonCotesResult, CompositeNewtonCotesResult)
for rendering formula() and error_term() strings."""
from fractions import Fraction


def derivative_notation(derivative_order: int) -> str:
    if derivative_order <= 3:
        return "'" * derivative_order
    return f"^({derivative_order})"


def signed_term(coeff: Fraction, expr: str) -> str:
    if coeff == 1:
        return expr
    if coeff == -1:
        return f"-{expr}"
    return f"{coeff}*{expr}"
