import warnings
import numpy as np
from typing import SupportsFloat
from dataclasses import dataclass
    
@dataclass(frozen=True)
class Polynomial:
    coeffs: np.ndarray # [a_n, a_{n-1}, ..., a_0]
    degree: int = 0  # Default value

    def __post_init__(self):
        object.__setattr__(self, 'coeffs', np.array(self.coeffs, dtype=float))
        # Calculate degree based on the length of the coefficients
        object.__setattr__(self, 'degree', len(self.coeffs) - 1)
        
    def __str__(self):
        monomials = []
        for degree, coeff in enumerate(reversed(self.coeffs)):
            if coeff == 0:
                continue
            if degree == 0:
                monomials.append(f"{coeff:.2g}")
            elif degree == 1 and coeff == 1:
                monomials.append("x")
            elif degree == 1 and coeff == -1:
                monomials.append("-x")
            elif degree == 1:
                monomials.append(f"{coeff:.2g}·x")
            elif coeff == 1:
                monomials.append(f"x^{degree}")
            elif coeff == -1:
                monomials.append(f"-x^{degree}")
            else:
                monomials.append(f"{coeff:.2g}·x^{degree}")
        
        return " + ".join(reversed(monomials)).replace("+ -", "- ")
    
    def __add__(self, other):
        if isinstance(other, (int, float, complex)):
            other = Polynomial([other])
        if not isinstance(other, Polynomial):
            return NotImplemented
        max_degree = max(self.degree, other.degree)
        new_coeffs = np.zeros(max_degree + 1)
        new_coeffs[-len(self.coeffs):] += self.coeffs
        new_coeffs[-len(other.coeffs):] += other.coeffs
        return Polynomial(new_coeffs)

    def __radd__(self, other):
        return self.__add__(other)

    def __mul__(self, other):
        if isinstance(other, Polynomial):
            return Polynomial(np.convolve(self.coeffs, other.coeffs))
        if isinstance(other, (int, float, complex)):
            return Polynomial(self.coeffs * other)
        return NotImplemented

    def __rmul__(self, other):
        return self.__mul__(other)

    def __pow__(self, n: int) -> 'Polynomial':
        if not isinstance(n, int) or n < 0:
            return NotImplemented
        result = Polynomial([1.0])
        base = self
        while n > 0:
            if n % 2 == 1:
                result = result * base
            base = base * base
            n //= 2
        return result
    
    def __sub__(self, other):
        if not isinstance(other, Polynomial):
            return NotImplemented
        return self + (-other)
    
    def __neg__(self):
        return Polynomial(-self.coeffs)
    
    def __truediv__(self, other):
        if isinstance(other, (int, float, complex)):
            if other == 0:
                raise ZeroDivisionError("Cannot divide by zero.")
            return 1/other * self
        if isinstance(other, Polynomial):
            return NotImplemented
        return NotImplemented
    
    def __eq__(self, other):
        if not isinstance(other, Polynomial):
            return NotImplemented
        return np.array_equal(self.coeffs, other.coeffs)
    
    def __hash__(self):
        return hash(tuple(self.coeffs))
    
    def from_roots(roots, multiplicities: np.ndarray = None) -> 'Polynomial':
        roots = np.asarray(list(roots) if not hasattr(roots, '__len__') else roots)
        if multiplicities is None:
            multiplicities = np.ones(len(roots), dtype=int)
        elif len(roots) != len(multiplicities):
            raise ValueError("Length of multiplicities must match length of roots.")
        res = Polynomial([1])
        for r, m in zip(roots, multiplicities):
            res *= Polynomial([1, -r])**m
        return res
        
    def horner(self, x0: float) -> 'HornerResult':
        n = self.degree
        q_coeffs = np.zeros(n) # Coefficients of Q(x)
        
        q_coeffs[0] = self.coeffs[0]
        p_deriv = q_coeffs[0]
        for k in range(1, n):
            q_coeffs[k] = self.coeffs[k] + x0 * q_coeffs[k-1]
            p_deriv = q_coeffs[k] + x0 * p_deriv
        
        p_val = self.coeffs[n] + x0 * q_coeffs[n-1]
        
        return HornerResult(
            value=p_val,
            derivative=p_deriv,
            quotient=Polynomial(q_coeffs)
        )    
        
    def _evaluate(self, x: SupportsFloat):
        p_val = self.coeffs[0]
        for i in range(1, self.degree + 1):
            p_val = self.coeffs[i] + x * p_val
        return p_val

    def __call__(self, x):
        if isinstance(x, (list, tuple, np.ndarray)):
            # Create a numpy array from the evaluated points
            return np.array([self._evaluate(val) for val in x], dtype=float)
        # Otherwise, treat as scalar
        return self._evaluate(x)
    
    def deflate(self, root: SupportsFloat):
        return self.horner(root).quotient

    def deflate_quadratic(self, r: complex) -> 'Polynomial':
        """Deflate by (x - r)(x - r̄) = x² - 2·Re(r)·x + |r|², keeping real coefficients."""
        p = -2 * r.real
        q = r.real**2 + r.imag**2
        a = self.coeffs
        n = self.degree
        b = np.zeros(n - 1)
        b[0] = a[0]
        b[1] = a[1] - p * b[0]
        for k in range(2, n - 1):
            b[k] = a[k] - p * b[k-1] - q * b[k-2]
        return Polynomial(b)

    def solve(self, x_hat: SupportsFloat, polish: bool = True, use_muller: bool = False) -> np.ndarray:
        from ..root_finding import Newton, Muller
        newton_solver = Newton()
        muller_solver = Muller() if use_muller else None
        roots = []
        current_poly = self

        while current_poly.degree > 2:
            if use_muller:
                x = float(x_hat)
                h = max(0.5, abs(x) * 0.1)
                result = muller_solver.solve(current_poly, p0=x - h, p1=x, p2=x + h)
                if not result.converged:
                    warnings.warn(
                        f"Müller's method failed during deflation; returning {len(roots)} of {self.degree} roots.",
                        RuntimeWarning
                    )
                    return np.array(roots)
                if result.complex_root is not None:
                    r = result.complex_root
                    roots.extend([r, r.conjugate()])
                    current_poly = current_poly.deflate_quadratic(r)
                    x_hat = r.real
                else:
                    roots.append(result.root)
                    current_poly = current_poly.deflate(result.root)
                    x_hat = result.root
            else:
                root = newton_solver.solve(current_poly, x_hat).root
                if root is None:
                    warnings.warn(
                        f"Newton's method failed during deflation; returning {len(roots)} of {self.degree} roots.",
                        RuntimeWarning
                    )
                    return np.array(roots, dtype=float)
                roots.append(root)
                current_poly = current_poly.deflate(root)
                x_hat = root

        if current_poly.degree == 2:
            roots.extend(current_poly.solve_quadratic())
        elif current_poly.degree == 1:
            roots.append(-current_poly.coeffs[1] / current_poly.coeffs[0])

        if polish:
            polished = []
            for r in roots:
                if np.iscomplex(r):
                    polished.append(r)
                    continue
                result = newton_solver.solve(self, r)
                if result.root is None:
                    warnings.warn(
                        f"Newton's method failed while polishing root {r}; keeping unpolished value.",
                        RuntimeWarning
                    )
                    polished.append(r)
                else:
                    polished.append(result.root)
            roots = polished

        return np.array(sorted(roots, key=lambda r: (complex(r).real, complex(r).imag)))

    def solve_quadratic(self) -> np.ndarray:
        if self.degree != 2:
            raise ValueError("The polynomial must be of degree 2 to use the quadratic formula.")
        a, b, c = self.coeffs
        discriminant = b**2 - 4*a*c
        sqrt_d = np.sqrt(complex(discriminant)) if discriminant < 0 else np.sqrt(discriminant)
        return np.array([(-b + sqrt_d) / (2*a), (-b - sqrt_d) / (2*a)])
    
    def derivative(self) -> 'Polynomial':
        n = self.degree
        coeffs = [self.coeffs[i] * (n - i) for i in range(n)]
        return Polynomial(coeffs)
    
    def integral(self, constant: float = 0.0) -> 'Polynomial':
        n = self.degree
        coeffs = [self.coeffs[i] / (n - i + 1) for i in range(n + 1)]
        coeffs.append(constant)
        return Polynomial(coeffs)

    def integrate(self, a: SupportsFloat, b: SupportsFloat) -> float:
        antiderivative = self.integral()
        return antiderivative(b) - antiderivative(a)

        
@dataclass(frozen=True)
class HornerResult:
    value: float
    derivative: float
    quotient: Polynomial