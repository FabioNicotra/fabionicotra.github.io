import numpy as np
from dataclasses import dataclass
from typing import SupportsFloat
from numpy.typing import NDArray
from .polynomial import Polynomial


@dataclass(frozen=True)
class NewtonPolynomial:
    nodes: NDArray[np.float64]   # x_0, ..., x_{n-1}  (n nodes, one per non-constant term)
    coeffs: NDArray[np.float64]  # a_0, ..., a_n       (n+1 divided-difference coefficients)

    def __post_init__(self):
        object.__setattr__(self, 'nodes', np.asarray(self.nodes, dtype=float))
        object.__setattr__(self, 'coeffs', np.asarray(self.coeffs, dtype=float))
        if self.nodes.ndim != 1 or self.coeffs.ndim != 1:
            raise ValueError("nodes and coeffs must be 1-D arrays.")
        if len(self.coeffs) != len(self.nodes) + 1:
            raise ValueError(
                f"len(coeffs) must equal len(nodes) + 1, "
                f"got {len(self.coeffs)} and {len(self.nodes)}."
            )

    @property
    def degree(self) -> int:
        return len(self.coeffs) - 1

    def _evaluate(self, x: float) -> float:
        result = self.coeffs[self.degree]
        for i in range(self.degree - 1, -1, -1):
            result = self.coeffs[i] + (x - self.nodes[i]) * result
        return result

    def __call__(self, x):
        if isinstance(x, (list, tuple, np.ndarray)):
            return np.array([self._evaluate(float(v)) for v in x], dtype=float)
        return self._evaluate(float(x))

    def to_polynomial(self) -> 'Polynomial':
        result = Polynomial([self.coeffs[0]])
        node_poly = Polynomial([1.0])
        for k in range(1, self.degree + 1):
            node_poly = node_poly * Polynomial([1.0, -self.nodes[k - 1]])
            result = result + self.coeffs[k] * node_poly
        return result

    def __str__(self) -> str:
        if self.degree == 0:
            return f"{self.coeffs[0]:.6g}"
        parts = [f"{self.coeffs[0]:.6g}"]
        for k in range(1, self.degree + 1):
            node_str = "·".join(f"(x - {self.nodes[j]:.6g})" for j in range(k))
            coeff = self.coeffs[k]
            sign = "+" if coeff >= 0 else "-"
            parts.append(f"{sign} {abs(coeff):.6g}·{node_str}")
        return " ".join(parts)
