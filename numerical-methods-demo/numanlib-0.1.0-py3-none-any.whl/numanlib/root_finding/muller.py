from .base import Solver
from .results import SolverResult
import numpy as np
from typing import Callable, SupportsFloat, Optional


class Muller(Solver):
    def solve(
        self,
        f: Callable,
        p0: SupportsFloat,
        p1: SupportsFloat,
        p2: SupportsFloat,
        tolerance: Optional[SupportsFloat] = None,
        max_iterations: Optional[int] = None,
    ) -> SolverResult:
        self._apply_overrides(tolerance, max_iterations)
        if not callable(f):
            raise TypeError("f must be a callable function.")
        for name, val in [("p0", p0), ("p1", p1), ("p2", p2)]:
            try:
                float(val)
            except (TypeError, ValueError):
                raise TypeError(f"{name} must be convertible to float.")
        try:
            float(f(float(p0)))
        except (TypeError, ValueError):
            raise TypeError("f must return a numeric value.")

        p0, p1, p2 = complex(p0), complex(p1), complex(p2)
        fp0, fp1, fp2 = complex(f(p0.real)), complex(f(p1.real)), complex(f(p2.real))

        h1 = p1 - p0
        h2 = p2 - p1
        delta1 = (fp1 - fp0) / h1
        delta2 = (fp2 - fp1) / h2
        d = (delta2 - delta1) / (h2 + h1)

        history = [p0.real, p1.real, p2.real]

        for i in range(self.max_iterations):
            b = delta2 + h2 * d
            D = np.sqrt(b ** 2 - 4 * fp2 * d)

            # Choose the sign that maximises |denominator| (numerical stability)
            E = b + D if abs(b + D) >= abs(b - D) else b - D

            if E == 0:
                return SolverResult.failure(
                    name=self.__class__.__name__,
                    history_list=history,
                    metadata={"function": f},
                    error_msg=f"Division by zero at iteration {i + 3}."
                )

            h = -2 * fp2 / E
            p = p2 + h
            history.append(p.real)

            if abs(h) < self.tolerance:
                if abs(p.imag) > self.tolerance:
                    return SolverResult.success(
                        name=self.__class__.__name__,
                        history_list=history,
                        metadata={"function": f},
                        complex_root=p
                    )
                return SolverResult.success(
                    name=self.__class__.__name__,
                    history_list=history,
                    metadata={"function": f}
                )

            try:
                fp_new = complex(f(p))
            except Exception as e:
                return SolverResult.failure(
                    name=self.__class__.__name__,
                    history_list=history,
                    metadata={"function": f},
                    error_msg=f"Function evaluation failed at iteration {i + 3}: {e}."
                )

            p0, p1, p2 = p1, p2, p
            fp0, fp1, fp2 = fp1, fp2, fp_new
            h1 = p1 - p0
            h2 = p2 - p1

            if h1 == 0 or h2 == 0:
                return SolverResult.failure(
                    name=self.__class__.__name__,
                    history_list=history,
                    metadata={"function": f},
                    error_msg=f"Method stagnated at iteration {i + 3}."
                )

            delta1 = (fp1 - fp0) / h1
            delta2 = (fp2 - fp1) / h2
            d = (delta2 - delta1) / (h2 + h1)

        return SolverResult.failure(
            name=self.__class__.__name__,
            history_list=history,
            metadata={"function": f},
            error_msg=f"Method did not converge after {self.max_iterations} iterations."
        )
