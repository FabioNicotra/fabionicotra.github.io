from dataclasses import dataclass
from typing import Callable, ClassVar, SupportsFloat, Optional
import numpy as np

from .base import Solver
from .results import SolverResult


@dataclass(frozen=True)
class BisectionResult(SolverResult):
    _iteration_offset: ClassVar[int] = 0

    def to_df(self):
        import pandas as pd
        index = list(range(1, len(self.history) + 1))
        table = pd.DataFrame({"p_i": self.history}, index=index)
        table.index.name = "iteration"
        f = self.metadata.get("function")
        if f is not None:
            table[self.function_column] = [f(pi) for pi in self.history]
        for col in ("a_i", "b_i"):
            vals = self.metadata.get(col)
            if vals is not None:
                table[col] = vals
        return table

class Bisection(Solver):
    def solve(
        self,
        f: Callable[[SupportsFloat], SupportsFloat],
        a: SupportsFloat,
        b: SupportsFloat,
        criterion: str = "absolute",
        tolerance: Optional[SupportsFloat] = None,
        max_iterations: Optional[int] = None,
    ) -> SolverResult:
        self._apply_overrides(tolerance, max_iterations)

        # Validate input types
        if not callable(f):
            raise TypeError("The first argument must be a callable function.")
        try:
            a = float(a)
            b = float(b)
        except (TypeError, ValueError):
            raise TypeError("The interval endpoints a and b must be convertible to float.")
        try:
            fa_i = float(f(a))
            fb_i = float(f(b))
        except (TypeError, ValueError):
            raise TypeError("The function f must return a numeric value for numeric inputs.")
        # Validate input values
        if a >= b:
            raise ValueError("Endpoint a must be less than endpoint b.")
        
        if np.sign(fa_i) * np.sign(fb_i) >= 0:
            return BisectionResult.failure(
                name=self.__class__.__name__,
                history_list=[],
                error_msg="The function must have opposite signs at the endpoints a and b."
            )
        
        # Initialize history list
        p = []
        fp = []
        a_values = []
        b_values = []
        a_i, b_i = a, b
        
        for i in range(self.max_iterations):
            half_width = (b_i - a_i) / 2
            p.append(a_i + half_width)
            a_values.append(a_i)
            b_values.append(b_i)
            fp.append(f(p[i]))
            stopping_condition = super()._eval_stopping_condition(p, f, criterion)
            if stopping_condition:
                return BisectionResult.success(
                    name=self.__class__.__name__,
                    history_list=p,
                    metadata={
                        "f(p_i)": fp,
                        "a_i": a_values,
                        "b_i": b_values,
                        "criterion": criterion,
                        "function": f
                    }
                )
            if np.sign(fp[i]) == np.sign(fa_i):
                a_i = p[i]
                fa_i = fp[i]
            else:
                b_i = p[i]
        return BisectionResult.failure(
            name=self.__class__.__name__,
            history_list=p,
            metadata={
                "f(p_i)": fp,
                "a_i": a_values,
                "b_i": b_values,
                "criterion": criterion,
                "function": f
            },
            error_msg=f"The method did not converge after {self.max_iterations} iterations."
        )
