from .base import Solver
from .results import SolverResult
import numpy as np
from typing import Callable, SupportsFloat, Optional

class Secant(Solver):
    def solve(
        self,
        f: Callable[[SupportsFloat], SupportsFloat],
        p0: SupportsFloat,
        p1: SupportsFloat,
        criterion: str = "absolute",
        tolerance: Optional[SupportsFloat] = None,
        max_iterations: Optional[int] = None,
    ) -> SolverResult:
        self._apply_overrides(tolerance, max_iterations)
        # Validate input types
        if not callable(f):
            raise TypeError("The first argument must be a callable function.")
        try:
            p0 = float(p0)
        except (TypeError, ValueError):
            raise TypeError("The initial guess p0 must be convertible to float.")
        try:
            p1 = float(p1)
        except (TypeError, ValueError):
            raise TypeError("The initial guess p1 must be convertible to float.")
        try:
            fp0 = float(f(p0))
        except (TypeError, ValueError):
            raise TypeError("The function f must return a float.")
        
        # Initialize history list
        p = [p0, p1]
        fp = [fp0, f(p1)]
        
        for i in range(2, self.max_iterations + 1):
            # Avoid division by zero
            if fp[i-1] == fp[i-2]:
                return SolverResult.failure(
                    name=self.__class__.__name__,
                    history_list=p,
                    metadata={
                        "f(p_i)": fp,
                        "function": f
                    },
                    error_msg=f"The method failed due to division by zero at iteration {i}."
                )
            # Find next approximation
            root = p[i-1] - fp[i-1] * (p[i-1] - p[i-2])/(fp[i-1] - fp[i-2])
            p.append(root)
            fp.append(f(root))
            
            # Check stopping condition
            if abs(p[i] - p[i-1]) < self.tolerance:
                return SolverResult.success(
                    name=self.__class__.__name__,
                    history_list=p,
                    metadata={
                        "f(p_i)": fp,
                        "function": f
                    }
                )
                
        return SolverResult.failure(
            name=self.__class__.__name__,
                history_list=p,
                metadata={
                    "f(p_i)": fp,
                    "function": f
                },
                error_msg=f"The method did not converge after {self.max_iterations} iterations."
        )
        