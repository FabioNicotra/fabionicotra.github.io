from abc import ABC, abstractmethod
from typing import SupportsFloat, Optional

class Solver(ABC):
    def __init__(self, tolerance: float = 1e-5, max_iterations: int = 100):
        self.tolerance = tolerance
        self.max_iterations = max_iterations

    @property
    def tolerance(self) -> float:
        return self._tolerance
    
    @tolerance.setter
    def tolerance(self, value: SupportsFloat):
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise TypeError("Tolerance must be a numeric value.")
        if value <= 0:
            raise ValueError("Tolerance must be a positive number.")
        self._tolerance = value

    @property
    def max_iterations(self) -> int:
        return self._max_iterations
    
    @max_iterations.setter
    def max_iterations(self, value: int):
        if not isinstance(value, int):
            raise TypeError("Max iterations must be an integer.")
        if value <= 0:
            raise ValueError("Max iterations must be a positive integer.")
        self._max_iterations = value

    def _apply_overrides(
        self,
        tolerance: Optional[SupportsFloat],
        max_iterations: Optional[int],
    ):
        if tolerance is not None:
            self.tolerance = tolerance
        if max_iterations is not None:
            self.max_iterations = max_iterations

    @abstractmethod
    def solve(self, *args, **kwargs):
        pass

    def _eval_stopping_condition(self, p, func, criterion) -> bool:
        if len(p) < 2:
            return False
        if criterion == "absolute":
            return func(p[-1]) == 0 or abs(p[-1] - p[-2]) < self.tolerance
        elif criterion == "relative":
            if p[-1] != 0:
                return abs((p[-1] - p[-2]) / p[-1]) < self.tolerance
            else:
                return abs(p[-1] - p[-2]) < self.tolerance
        elif criterion == "function_value":
            return abs(func(p[-1])) < self.tolerance
        else:
            raise ValueError("Invalid stopping criterion. Must be 'absolute', 'relative', or 'function_value'.")
