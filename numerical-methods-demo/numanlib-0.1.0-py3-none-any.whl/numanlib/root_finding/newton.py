from .base import Solver
from .results import SolverResult
from ..core import Polynomial
import numpy as np
from typing import Callable, SupportsFloat, List, Dict, Any, Optional

class BaseNewton(Solver):
    def _validate_inputs(self, p0: SupportsFloat, *funcs: Callable):
        # Convert p0
        try:
            p_float = float(p0)
        except (TypeError, ValueError):
            raise TypeError(f"The initial guess p0 must be convertible to float, got {type(p0).__name__}")
        
        if isinstance(funcs[0], Polynomial):
            # funcs[1] is expected to be None
            if funcs[1] is not None:
                raise ValueError(f"Argument {funcs[1]} expected to be None.")
        else:
            for func in funcs:
                # Check that funcs are callable
                if not callable(func):
                    raise TypeError(f"Argument {func} must be a callable function.")
                # Probe outputs 
                try:
                    float(func(p_float))
                except (TypeError, ValueError):
                    raise TypeError(f"Function {func.__name__} must return a float-compatible value.")
            
        return p_float
    
    def _get_metadata(self, f: Callable, df: Callable) -> Dict[str, Any]:
        return {
            "function": f,
            "derivative": df
        }
            
    def _run_solver(
        self,
        f: Callable[[SupportsFloat], SupportsFloat],
        df: Callable[[SupportsFloat], SupportsFloat],
        p0: SupportsFloat,
        update_logic: Callable[[SupportsFloat], SupportsFloat],
        criterion: str 
    ) -> SolverResult:
        # Inputs are validated by the calling subclass
        p = [p0]
        
        # Calculate next approximation
        for i in range(1, self.max_iterations + 1):
            try:
                p_next = update_logic(p[-1])
            except (ZeroDivisionError, ValueError, TypeError) as e:
                return SolverResult.failure(
                    name=self.__class__.__name__,
                    history_list=p,
                    metadata=self._get_metadata(f, df),
                    error_msg=f"The method failed after {i} iterations: {str(e)}"
                )
            if not np.isfinite(p_next):
                return SolverResult.failure(
                    name=self.__class__.__name__,
                    history_list=p,
                    metadata=self._get_metadata(f, df),
                    error_msg=f"The method failed after {i} iterations: derivative is zero or result is non-finite."
                )
            p.append(p_next)
                
            stopping_condition = super()._eval_stopping_condition(p, f, criterion)
            if stopping_condition:
                return SolverResult.success(
                    name=self.__class__.__name__,
                    history_list=p,
                    metadata=self._get_metadata(f, df)
                )
        return SolverResult.failure(
            name=self.__class__.__name__,
            history_list=p,
            metadata=self._get_metadata(f, df),
            error_msg=f"The method did not converge after {self.max_iterations} iterations."
        )
    
class Newton(BaseNewton):
    def solve(
        self,
        f: Callable[[SupportsFloat], SupportsFloat],
        p0: SupportsFloat,
        df: Optional[Callable[[SupportsFloat], SupportsFloat]] = None,
        criterion: str = "absolute",
        tolerance: Optional[SupportsFloat] = None,
        max_iterations: Optional[int] = None,
    ) -> SolverResult:
        self._apply_overrides(tolerance, max_iterations)
        p0 = self._validate_inputs(p0, f, df)
        if df is None and isinstance(f, Polynomial):
            df = lambda p: f.horner(p).derivative
        update = lambda p: p - f(p) / df(p)
        return self._run_solver(f, df, p0, update, criterion)


class ModifiedNewton(BaseNewton):
    def solve(
        self,
        f: Callable[[SupportsFloat], SupportsFloat],
        p0: SupportsFloat,
        df: Callable[[SupportsFloat], SupportsFloat],
        ddf: Callable[[SupportsFloat], SupportsFloat],
        criterion: str = "absolute",
        tolerance: Optional[SupportsFloat] = None,
        max_iterations: Optional[int] = None,
    ) -> SolverResult:
        self._apply_overrides(tolerance, max_iterations)
        p0 = self._validate_inputs(p0, f, df, ddf)
        update = lambda p: p - f(p) * df(p) / (df(p)**2 - f(p) * ddf(p))
        return self._run_solver(f, df, p0, update, criterion)