from dataclasses import dataclass, field
from typing import ClassVar, List, Optional, Dict, Any
import numpy as np
from numpy.typing import NDArray
import pandas as pd


@dataclass(frozen=True)
class SolverResult:
    method_name: str
    root: Optional[float]
    iterations: int
    converged: bool
    history: NDArray[np.float64]
    metadata: Dict[str, Any] = field(default_factory=dict)
    error_msg: Optional[str] = None
    complex_root: Optional[complex] = None

    function_column: ClassVar[str] = "f(p_i)"
    _iteration_offset: ClassVar[int] = -1

    def __repr__(self):
        status_str = "converged" if self.converged else "failed"
        iterations_str = f" in {self.iterations} iterations" if self.iterations > 0 else ""
        ret = f"{self.method_name} method {status_str}{iterations_str}\n"
        if self.complex_root is not None:
            ret += f"Root: {self.complex_root}\n"
        elif self.root is not None:
            ret += f"Root: {self.root:.8g}\n"
        if self.error_msg:
            ret += f"Error: {self.error_msg}\n"
        return ret

    @classmethod
    def success(cls, name: str, history_list: List[float], metadata: Dict[str, Any] = None, complex_root: Optional[complex] = None):
        return cls(
            method_name=name,
            root=None if complex_root is not None else history_list[-1],
            iterations=len(history_list) + cls._iteration_offset,
            converged=True,
            history=np.array(history_list, dtype=np.float64),
            metadata=metadata or {},
            complex_root=complex_root
        )

    @classmethod
    def failure(cls, name: str, history_list: List[float], error_msg: str, metadata: Dict[str, Any] = None):
        return cls(
            method_name=name,
            root=None,
            iterations=len(history_list) + cls._iteration_offset,
            converged=False,
            history=np.array(history_list, dtype=np.float64),
            error_msg=error_msg,
            metadata=metadata or {}
        )

    def to_df(self) -> pd.DataFrame:
        index = list(range(len(self.history)))
        table = pd.DataFrame({"p_i": self.history}, index=index)
        table.index.name = "iteration"

        f = self.metadata.get("function")
        if f is not None:
            table[self.function_column] = [f(pi) for pi in self.history]

        df = self.metadata.get("derivative")
        if df is not None:
            table["df(p_i)"] = [df(pi) for pi in self.history]

        return table

    def _is_sequential(self, value) -> bool:
        return isinstance(value, (list, np.ndarray, tuple)) and len(value) == len(self.history)
