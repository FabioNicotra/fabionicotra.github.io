from dataclasses import dataclass
from typing import Callable, ClassVar, SupportsFloat, Optional
import numpy as np

from .base import Solver
from .results import SolverResult


@dataclass(frozen=True)
class FixedPointResult(SolverResult):
    function_column: ClassVar[str] = "g(p_i)"

class FixedPoint(Solver):
    def solve(
        self,
        g: Callable[[SupportsFloat], SupportsFloat],
        p0: SupportsFloat,
        tolerance: Optional[SupportsFloat] = None,
        max_iterations: Optional[int] = None,
    ) -> SolverResult:
        self._apply_overrides(tolerance, max_iterations)

        # Validate input types
        if not callable(g):
            raise TypeError("The first argument must be a callable function.")
        try:
            p0 = float(p0)
        except (TypeError, ValueError):
            raise TypeError("The initial guess p0 must be convertible to float.")
        try:
            gp0 = float(g(p0))
        except (TypeError, ValueError):
            raise TypeError("The function g must return a float.")
        
        # Initialize history list
        p = [p0]
        for i in range(self.max_iterations):
            p_next = g(p[i])
            p.append(p_next)
            
            if abs(p_next - p[i]) < self.tolerance:
                return FixedPointResult.success(
                    name=self.__class__.__name__,
                    history_list=p,
                    metadata=self._get_metadata(g)
                )
        
        return FixedPointResult.failure(
            name=self.__class__.__name__,
            history_list=p,
            metadata=self._get_metadata(g),
            error_msg=f"The method did not converge after {self.max_iterations} iterations."
            )
        
    def _get_metadata(self, g: Callable) -> dict:
        return {
            "function": g
        }
            
