from dataclasses import dataclass, field
from fractions import Fraction
from math import factorial
from typing import Any, Callable, Dict, List, SupportsFloat, Tuple
import numpy as np
import pandas as pd
from numpy.typing import NDArray

from ..core.formatting import derivative_notation, signed_term
from ..interpolation import lagrange


def _rational_coefficients(weights: NDArray[np.float64], h: float) -> List[Fraction]:
    return [Fraction(w / h).limit_denominator(10_000) for w in weights]


def _panel_weights(rule: NewtonCotesRule, h: float) -> Tuple[NDArray[np.float64], int, int]:
    """Weights for a single application of `rule` with node spacing h,
    plus the integration bounds (s_a, s_b) in the offset variable s.

    Interpolate in the offset variable s rather than in x directly: the
    offsets are always small integers near the origin, so the monomial
    expansion inside lagrange() stays well-conditioned regardless of how
    large a/b are or how small h is (same conditioning fix used by
    finite_difference()). Integrating the basis polynomials over [s_a, s_b]
    gives the classic Newton-Cotes weights. The basis polynomials depend
    only on the offsets, never on f, so dummy y-values suffice here.
    """
    n = len(rule.offsets) - 1
    s_a, s_b = (0, n) if rule.closed else (-1, n + 1)
    lag = lagrange(rule.offsets, np.zeros_like(rule.offsets))
    basis_polynomials = lag.metadata["basis_polynomials"]
    weights = np.array([h * basis.integrate(s_a, s_b) for basis in basis_polynomials])
    return weights, s_a, s_b


def _error_term(coeffs: List[Fraction], offsets: NDArray, s_a: int, s_b: int) -> Tuple[int, Fraction]:
    n = len(offsets) - 1
    j = n + 1
    while j <= n + 6:
        true_integral = Fraction(s_b ** (j + 1) - s_a ** (j + 1), j + 1)
        leak = sum(c * Fraction(int(o)) ** j for c, o in zip(coeffs, offsets)) - true_integral
        if leak != 0:
            return j + 1, leak / factorial(j)
        j += 1
    raise RuntimeError("Could not determine the truncation-error term for this rule.")


@dataclass(frozen=True)
class NewtonCotesRule:
    """A Newton-Cotes node specification: offsets = [0, 1, ..., n] paired
    with whether the rule is closed (endpoints a, b are nodes) or open
    (a, b are used only to define h, never evaluated). Bundling the two
    together means a rule is always fully specified by one object - passing
    SIMPSONS with closed=False can't happen, since SIMPSONS already carries
    closed=True internally, even though its offsets are identical to
    OPEN_NEWTON_COTES_2's.
    """

    offsets: NDArray[np.int_]
    closed: bool

    def __post_init__(self):
        if not isinstance(self.closed, bool):
            raise TypeError("closed must be a boolean.")
        offsets = np.array(self.offsets, dtype=float)
        if offsets.ndim != 1:
            raise ValueError("offsets must be a 1-D array.")
        if len(offsets) == 0:
            raise ValueError("offsets must contain at least one node.")
        n = len(offsets) - 1
        if not np.array_equal(offsets, np.arange(n + 1)):
            raise ValueError(
                "offsets must be the consecutive integers [0, 1, ..., n]; "
                "Newton-Cotes formulas use every equally spaced node in the rule."
            )
        if self.closed and n == 0:
            raise ValueError(
                "closed Newton-Cotes formulas require at least 2 offsets "
                "(offsets=[0, 1, ..., n] with n >= 1); use closed=False for a "
                "single-node rule."
            )
        object.__setattr__(self, "offsets", offsets)


# Closed Newton-Cotes formulas: offsets = [0, 1, ..., n] span every node in
# [a, b], including both endpoints.
TRAPEZOIDAL = NewtonCotesRule(np.array([0, 1]), closed=True)
SIMPSONS = NewtonCotesRule(np.array([0, 1, 2]), closed=True)
SIMPSONS_THREE_EIGHTHS = NewtonCotesRule(np.array([0, 1, 2, 3]), closed=True)
BOOLES = NewtonCotesRule(np.array([0, 1, 2, 3, 4]), closed=True)

# Open Newton-Cotes formulas: offsets index only the interior nodes; the
# endpoints a and b are used solely to define h, never evaluated. Note that
# SIMPSONS and OPEN_NEWTON_COTES_2 share the same offsets array by
# coincidence - it is the `closed` field, not the offsets, that determines h
# and node placement, so the two presets compute entirely different rules.
MIDPOINT = NewtonCotesRule(np.array([0]), closed=False)
OPEN_NEWTON_COTES_1 = NewtonCotesRule(np.array([0, 1]), closed=False)
OPEN_NEWTON_COTES_2 = NewtonCotesRule(np.array([0, 1, 2]), closed=False)
OPEN_NEWTON_COTES_3 = NewtonCotesRule(np.array([0, 1, 2, 3]), closed=False)


@dataclass(frozen=True, kw_only=True)
class NewtonCotesResult:
    value: float
    a: float
    b: float
    n: int
    closed: bool
    h: float
    nodes: NDArray[np.float64]
    f_values: NDArray[np.float64]
    weights: NDArray[np.float64]
    error_order: int
    error_coefficient: Fraction
    method_name: str = "Newton-Cotes"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        kind = "closed" if self.closed else "open"
        return (
            f"{self.method_name} ({kind}, n={self.n}): "
            f"∫[{self.a},{self.b}] f(x)dx ≈ {self.value} "
            f"({len(self.nodes)} points, h={self.h}, O(h^{self.error_order}))\n"
        )

    def to_df(self) -> pd.DataFrame:
        table = pd.DataFrame({
            "node": self.nodes,
            "f(node)": self.f_values,
            "weight": self.weights,
        })
        table.index.name = "i"
        return table

    def _error_expr(self, coeff: Fraction) -> str:
        k = self.error_order - 1
        deriv = derivative_notation(k)
        return signed_term(coeff, f"h^{self.error_order}*f{deriv}(ξ)")

    def formula(self) -> str:
        coeffs = _rational_coefficients(self.weights, self.h)
        terms = [
            signed_term(frac, f"f(x{i})")
            for i, frac in enumerate(coeffs)
            if frac != 0
        ]
        rhs = " + ".join(terms).replace("+ -", "- ")

        # exact = value - error_coefficient * h^error_order * f^(k)(ξ)
        error_part = self._error_expr(-self.error_coefficient)
        return f"∫f(x)dx = h*({rhs}) + {error_part}".replace("+ -", "- ")

    def error_term(self) -> str:
        return f"error ≈ {self._error_expr(self.error_coefficient)}"

    def error_bound(self, M: SupportsFloat) -> float:
        return abs(float(self.error_coefficient)) * abs(self.h) ** self.error_order * float(M)


def newton_cotes(
    f: Callable[[SupportsFloat], SupportsFloat],
    a: SupportsFloat,
    b: SupportsFloat,
    rule: NewtonCotesRule = None,
    offsets: NDArray = None,
    closed: bool = None,
) -> NewtonCotesResult:
    if not callable(f):
        raise TypeError("f must be a callable function.")
    try:
        a = float(a)
        b = float(b)
    except (TypeError, ValueError):
        raise TypeError("a and b must be numeric values.")
    if b <= a:
        raise ValueError("b must be greater than a.")

    # Either pass a preset (or hand-built) rule directly, or specify offsets
    # and closed manually - never a mix of the two, so a rule is always
    # fully specified by exactly one source.
    if rule is not None:
        if offsets is not None or closed is not None:
            raise TypeError(
                "pass either rule=... or offsets=...+closed=..., not both."
            )
        if not isinstance(rule, NewtonCotesRule):
            raise TypeError("rule must be a NewtonCotesRule.")
    else:
        if offsets is None or closed is None:
            raise TypeError(
                "pass either a preset (rule=...), or both offsets=... and "
                "closed=... for a custom stencil."
            )
        rule = NewtonCotesRule(offsets, closed)

    offsets, closed = rule.offsets, rule.closed
    n = len(offsets) - 1

    if closed:
        h = (b - a) / n
        nodes = a + h * offsets
    else:
        h = (b - a) / (n + 2)
        nodes = a + h * (offsets + 1)

    f_values = np.array([f(node) for node in nodes], dtype=float)
    weights, s_a, s_b = _panel_weights(rule, h)
    value = weights @ f_values

    coeffs = _rational_coefficients(weights, h)
    offsets_int = np.round(offsets).astype(int)
    error_order, error_coefficient = _error_term(coeffs, offsets_int, s_a, s_b)

    return NewtonCotesResult(
        value=value,
        a=a,
        b=b,
        n=n,
        closed=closed,
        h=h,
        nodes=nodes,
        f_values=f_values,
        weights=weights,
        error_order=error_order,
        error_coefficient=error_coefficient,
        metadata={"function": f},
    )
