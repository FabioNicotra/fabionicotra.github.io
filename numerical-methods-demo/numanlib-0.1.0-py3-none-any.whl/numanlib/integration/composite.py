from dataclasses import dataclass
from fractions import Fraction
from typing import Callable, SupportsFloat
import numpy as np

from ..core.formatting import derivative_notation, signed_term
from .newton_cotes import (
    NewtonCotesResult,
    NewtonCotesRule,
    _error_term,
    _panel_weights,
    _rational_coefficients,
)


@dataclass(frozen=True, kw_only=True)
class CompositeNewtonCotesResult(NewtonCotesResult):
    """A NewtonCotesResult whose rule was applied panel by panel: `nodes`,
    `f_values`, and `weights` span the whole of [a, b], and the error term
    carries the composite (b-a)*h^(k-1) form instead of the single rule's
    h^k. `to_df()`, `formula()`, and `error_term()` are inherited unchanged -
    only the error expression, bound, and repr differ.
    """

    subintervals: int
    panels: int
    method_name: str = "Composite Newton-Cotes"

    def __repr__(self) -> str:
        kind = "closed" if self.closed else "open"
        return (
            f"{self.method_name} ({kind}, n={self.n}, {self.panels} panels): "
            f"∫[{self.a},{self.b}] f(x)dx ≈ {self.value} "
            f"({len(self.nodes)} points, h={self.h}, O(h^{self.error_order}))\n"
        )

    def _error_expr(self, coeff: Fraction) -> str:
        # For composite rules the h-power drops by one relative to the single
        # rule, but the derivative order does not, so it equals error_order.
        deriv = derivative_notation(self.error_order)
        return signed_term(coeff, f"(b-a)*h^{self.error_order}*f{deriv}(µ)")

    def error_bound(self, M: SupportsFloat) -> float:
        return (
            abs(float(self.error_coefficient))
            * (self.b - self.a)
            * abs(self.h) ** self.error_order
            * float(M)
        )


def composite_newton_cotes(
    f: Callable[[SupportsFloat], SupportsFloat],
    a: SupportsFloat,
    b: SupportsFloat,
    rule: NewtonCotesRule = None,
    subintervals: int = None,
) -> 'CompositeNewtonCotesResult':
    if not callable(f):
        raise TypeError("f must be a callable function.")
    try:
        a = float(a)
        b = float(b)
    except (TypeError, ValueError):
        raise TypeError("a and b must be numeric values.")
    if b <= a:
        raise ValueError("b must be greater than a.")
    if rule is None:
        raise TypeError("rule must be provided, e.g. rule=SIMPSONS.")
    if not isinstance(rule, NewtonCotesRule):
        raise TypeError("rule must be a NewtonCotesRule.")
    if isinstance(subintervals, bool) or not isinstance(subintervals, (int, np.integer)):
        raise TypeError("subintervals must be an integer.")
    subintervals = int(subintervals)

    offsets, closed = rule.offsets, rule.closed
    n = len(offsets) - 1

    # Burden & Faires subinterval conventions: for closed rules
    # h = (b-a)/subintervals and each panel spans n subintervals
    # (Theorem 4.4/4.5); for open rules h = (b-a)/(subintervals+2) and each
    # panel spans n+2 subintervals, its two outermost ones never evaluated
    # (Theorem 4.6 - e.g. Composite Midpoint requires subintervals even,
    # with subintervals=0 being the plain single-application Midpoint rule).
    if closed:
        if subintervals < 1 or subintervals % n != 0:
            raise ValueError(
                f"subintervals must be a positive multiple of {n} for this "
                f"closed rule: each panel spans {n} subintervals."
            )
        panels = subintervals // n
        panel_span = n
        h = (b - a) / subintervals
        nodes = a + h * np.arange(subintervals + 1)
    else:
        if subintervals < 0 or (subintervals + 2) % (n + 2) != 0:
            raise ValueError(
                f"subintervals must be non-negative with subintervals + 2 a "
                f"multiple of {n + 2} for this open rule: each panel spans "
                f"{n + 2} subintervals."
            )
        panels = (subintervals + 2) // (n + 2)
        panel_span = n + 2
        h = (b - a) / (subintervals + 2)
        starts = panel_span * np.arange(panels)
        nodes = a + h * (starts[:, None] + offsets[None, :] + 1).ravel()

    # Uniform spacing means every panel has the same weight vector up to
    # translation, so compute it once and accumulate it into a global vector.
    # Closed panels share their boundary nodes, whose weights therefore sum -
    # this is exactly where the textbook 1, 4, 2, ..., 4, 1 patterns come
    # from - while open panels abut without sharing nodes. Each distinct node
    # is evaluated exactly once.
    panel_weights, s_a, s_b = _panel_weights(rule, h)
    if closed:
        weights = np.zeros(subintervals + 1)
        for p in range(panels):
            weights[p * n : p * n + n + 1] += panel_weights
    else:
        weights = np.tile(panel_weights, panels)

    f_values = np.array([f(node) for node in nodes], dtype=float)
    value = weights @ f_values

    # Per-panel error is C*h^k*f^(k-1)(ξ); summing over the panels and
    # applying the Intermediate Value Theorem (B&F p. 205) turns the panel
    # count into (b-a)/(panel_span*h), so the composite error is
    # (C/panel_span)*(b-a)*h^(k-1)*f^(k-1)(µ).
    coeffs = _rational_coefficients(panel_weights, h)
    offsets_int = np.round(offsets).astype(int)
    single_order, single_coefficient = _error_term(coeffs, offsets_int, s_a, s_b)
    error_order = single_order - 1
    error_coefficient = single_coefficient / panel_span

    return CompositeNewtonCotesResult(
        value=value,
        a=a,
        b=b,
        n=n,
        closed=closed,
        h=h,
        subintervals=subintervals,
        panels=panels,
        nodes=nodes,
        f_values=f_values,
        weights=weights,
        error_order=error_order,
        error_coefficient=error_coefficient,
        metadata={"function": f, "rule": rule},
    )
