from .composite import (
    CompositeNewtonCotesResult,
    composite_newton_cotes,
)
from .newton_cotes import (
    NewtonCotesRule,
    NewtonCotesResult,
    newton_cotes,
    TRAPEZOIDAL,
    SIMPSONS,
    SIMPSONS_THREE_EIGHTHS,
    BOOLES,
    MIDPOINT,
    OPEN_NEWTON_COTES_1,
    OPEN_NEWTON_COTES_2,
    OPEN_NEWTON_COTES_3,
)

__all__ = [
    "CompositeNewtonCotesResult",
    "composite_newton_cotes",
    "NewtonCotesRule",
    "NewtonCotesResult",
    "newton_cotes",
    "TRAPEZOIDAL",
    "SIMPSONS",
    "SIMPSONS_THREE_EIGHTHS",
    "BOOLES",
    "MIDPOINT",
    "OPEN_NEWTON_COTES_1",
    "OPEN_NEWTON_COTES_2",
    "OPEN_NEWTON_COTES_3",
]
