import matplotlib.pyplot as plt
import numpy as np
from typing import Any, Callable, Literal, Optional
from ..interpolation.lagrange import LagrangeResult
from .base import BasePlotter

PlotType = Literal["basis", "interpolant"]


class InterpolantPlotter(BasePlotter):
    _default_plot_type = "interpolant"
    def _plot_range(self, result: Any):
        span = result.x[-1] - result.x[0]
        pad = 0.1 * span
        return np.linspace(result.x[0] - pad, result.x[-1] + pad, 400)

    def _plot_basis(self, result: Any, ax: plt.Axes):
        if not isinstance(result, LagrangeResult):
            raise TypeError("Basis plot is only supported for LagrangeResult.")
        basis = result.metadata.get("basis_polynomials", [])
        t = self._plot_range(result)
        colors = plt.cm.tab10(np.linspace(0, 1, len(basis)))

        for k, (L_k, c) in enumerate(zip(basis, colors)):
            ax.plot(t, L_k(t), color=c, label=f"$L_{k}$")
            ax.axvline(result.x[k], color=c, linestyle=":", linewidth=0.8)

        ax.axhline(0, color="black", linewidth=0.5)
        ax.axhline(1, color="black", linewidth=0.5, linestyle="--")
        ax.scatter(result.x, np.ones_like(result.x), zorder=5,
                   color=colors, edgecolors="black", s=60)

        ax.set_title("Lagrange basis polynomials $L_k(x)$")
        ax.set_xlabel("$x$")
        ax.legend(ncol=2, fontsize=9)
        ax.set_ylim(-0.6, 1.4)
        ax.grid(True)
        return ax

    def _plot_interpolant(
        self,
        result: Any,
        ax: plt.Axes,
        func: Optional[Callable] = None,
    ):
        t = self._plot_range(result)

        if func is not None:
            ax.plot(t, func(t), "k--", linewidth=1.5, label="$f(x)$")

        ax.plot(t, result.polynomial(t), color="steelblue", linewidth=2,
                label=f"{result.method_name} $P(x)$")
        ax.scatter(result.x, result.y, zorder=5, color="steelblue",
                   edgecolors="black", s=70, label="nodes")

        ax.set_title("Interpolant")
        ax.set_xlabel("$x$")
        ax.legend(fontsize=9)
        ax.grid(True)
        return ax
