import matplotlib.pyplot as plt
from .style import SCIENTIFIC_STYLE


class BasePlotter:
    _default_plot_type: str = ""

    def __init__(self, style_dict=None):
        self.style = style_dict or SCIENTIFIC_STYLE

    def plot(self, result, plot_type=None, ax=None, **kwargs) -> plt.Axes:
        if plot_type is None:
            plot_type = self._default_plot_type
        handler = getattr(self, f"_plot_{plot_type}", None)
        if handler is None:
            valid = [n[6:] for n in dir(self) if n.startswith("_plot_")]
            raise ValueError(
                f"Unsupported plot type: {plot_type!r}. "
                f"Supported types: {valid}"
            )
        with plt.rc_context(self.style):
            if ax is None:
                _, ax = plt.subplots()
            return handler(result, ax, **kwargs)
