import matplotlib.pyplot as plt
import numpy as np
from typing import Literal

from ..differentiation.finite_differences import FiniteDifferenceResult
from .base import BasePlotter

PlotType = Literal["derivative"]


class DifferentiationPlotter(BasePlotter):
    _default_plot_type = "derivative"

    def _domain(self, result: FiniteDifferenceResult) -> np.ndarray:
        node_min = min(np.min(result.nodes), result.x0)
        node_max = max(np.max(result.nodes), result.x0)
        node_span = node_max - node_min
        # Node spacing shrinks with h, but the plot should still show enough
        # of f's shape around x0 to give visual context - so the window is
        # sized relative to x0 (or a fixed floor near x0=0), only falling
        # back to the node span itself if that's the larger extent.
        half_width = max(10 * node_span, 0.5 * max(abs(result.x0), 1.0))
        return np.linspace(result.x0 - half_width, result.x0 + half_width, 400)

    def _get_f(self, result: FiniteDifferenceResult):
        f = result.metadata.get("function")
        if not f:
            raise ValueError("Function not found in metadata.")
        return f

    def _plot_derivative(
        self, result: FiniteDifferenceResult, ax: plt.Axes, show_nodes: bool = False,
        derivative_bound: float | None = None
    ) -> plt.Axes:
        f = self._get_f(result)
        t = self._domain(result)
        f0 = f(result.x0)

        ax.plot(t, f(t), color="black", linewidth=1.5, label="$f(x)$")

        if result.derivative_order == 1:
            tangent = f0 + result.value * (t - result.x0)
            ax.plot(t, tangent, color="steelblue", linewidth=2,
                     label=f"tangent, slope={result.value:.4g}")

            if derivative_bound is not None:
                err = result.error_bound(derivative_bound)
                upper_tangent = f0 + (result.value + err) * (t - result.x0)
                lower_tangent = f0 + (result.value - err) * (t - result.x0)
                ax.fill_between(
                    t, lower_tangent, upper_tangent,
                    color="steelblue", alpha=0.25,
                    label=f"slope uncertainty (M={derivative_bound:.4g})",
                )

        if show_nodes:
            ax.scatter(result.nodes, result.f_values, zorder=5, color="steelblue",
                       edgecolors="black", s=70, label="nodes")

        ax.scatter([result.x0], [f0], zorder=10, color="crimson",
                   edgecolors="black", s=110, label="$x_0$")

        self._format_axes(ax, result)
        return ax

    def _format_axes(self, ax: plt.Axes, result: FiniteDifferenceResult):
        if result.derivative_order == 1:
            title = f"Tangent Line Approximation at $x_0={result.x0:.3g}$"
        else:
            title = f"Finite Difference Result at $x_0={result.x0:.3g}$"
        ax.set_title(title)
        ax.set_xlabel("$x$")
        ax.set_ylabel("$f(x)$")
        ax.legend(fontsize=9)
        ax.grid(True)
