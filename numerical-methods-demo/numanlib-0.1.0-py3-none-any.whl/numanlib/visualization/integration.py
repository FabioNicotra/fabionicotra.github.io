import matplotlib.pyplot as plt
import numpy as np
from typing import Literal, Union

from ..integration.composite import CompositeNewtonCotesResult
from ..integration.newton_cotes import NewtonCotesResult
from ..interpolation import lagrange
from .base import BasePlotter

PlotType = Literal["area"]
IntegrationResult = Union[NewtonCotesResult, CompositeNewtonCotesResult]


class IntegrationPlotter(BasePlotter):
    _default_plot_type = "area"

    def _get_f(self, result: IntegrationResult):
        f = result.metadata.get("function")
        if not f:
            raise ValueError("Function not found in metadata.")
        return f

    def _plot_area(
        self, result: IntegrationResult, ax: plt.Axes, show_nodes: bool = True
    ) -> plt.Axes:
        f = self._get_f(result)
        margin = 0.15 * (result.b - result.a)
        t = np.linspace(result.a - margin, result.b + margin, 400)
        ax.plot(t, f(t), color="black", linewidth=1.5, label="$f(x)$")

        if isinstance(result, CompositeNewtonCotesResult):
            self._shade_composite(result, ax)
        else:
            self._shade_single(result, ax)

        if show_nodes:
            ax.scatter(
                result.nodes, result.f_values, zorder=5, color="crimson",
                edgecolors="black", s=70, label="nodes",
            )

        self._format_axes(ax, result)
        return ax

    def _shade_single(self, result: NewtonCotesResult, ax: plt.Axes):
        # Node i always sits at offset i by construction (offsets are
        # validated to be [0, ..., n]), so index == offset. Rebuilding the
        # interpolant this way, and mapping s back through the same
        # a + h*(s+shift) relation used by newton_cotes(), always spans
        # exactly [a, b] for both open and closed rules - so the shaded
        # region is the area the rule actually approximates (not the true
        # area under f), and stays correct even for e.g. Midpoint, whose
        # flat interpolant is extrapolated out to the endpoints it never
        # evaluates.
        shift = 0 if result.closed else 1
        s_a, s_b = (0, result.n) if result.closed else (-1, result.n + 1)
        offsets = np.arange(len(result.nodes), dtype=float)
        interp = lagrange(offsets, result.f_values)
        s_curve = np.linspace(s_a, s_b, 200)
        x_curve = result.a + result.h * (s_curve + shift)
        y_curve = interp.polynomial(s_curve)

        ax.fill_between(x_curve, y_curve, color="steelblue", alpha=0.25)
        ax.plot(x_curve, y_curve, color="steelblue", linewidth=2, label="interpolant")

        # Encircle the shaded region: left/right edges run from the axis up
        # to the interpolant's value at a and b (x_curve/y_curve already
        # span exactly [a, b], per the note above) - for open rules like
        # Midpoint this is the curve's extrapolated value at the interval
        # boundary, not the value at the nearest interior node.
        ax.vlines(
            [x_curve[0], x_curve[-1]], 0, [y_curve[0], y_curve[-1]],
            color="steelblue", linewidth=0.8,
        )
        ax.hlines(0, x_curve[0], x_curve[-1], color="steelblue", linewidth=0.8)

    def _shade_composite(self, result: CompositeNewtonCotesResult, ax: plt.Axes):
        # Same offset-space reconstruction as _shade_single, but panel by
        # panel: each panel spans [panel_a, panel_a + panel_span*h] and holds
        # its own low-order interpolant. Closed panels share their boundary
        # node with the next panel (stride n), open panels don't share any
        # nodes (stride n+1). Alternating fill alpha makes the panel
        # structure visible.
        nodes_per_panel = result.n + 1
        stride = result.n if result.closed else nodes_per_panel
        panel_span = result.n if result.closed else result.n + 2
        shift = 0 if result.closed else 1
        s_a, s_b = (0, result.n) if result.closed else (-1, result.n + 1)
        offsets = np.arange(nodes_per_panel, dtype=float)
        s_curve = np.linspace(s_a, s_b, 60)

        for p in range(result.panels):
            start = p * stride
            panel_f = result.f_values[start : start + nodes_per_panel]
            panel_a = result.a + result.h * panel_span * p
            interp = lagrange(offsets, panel_f)
            x_curve = panel_a + result.h * (s_curve + shift)
            y_curve = interp.polynomial(s_curve)

            ax.fill_between(
                x_curve, y_curve, color="steelblue",
                alpha=0.25 if p % 2 == 0 else 0.15,
            )
            ax.plot(
                x_curve, y_curve, color="steelblue", linewidth=2,
                label="interpolant" if p == 0 else None,
            )
            # Panel edges run from the axis up to the panel interpolant's
            # boundary values; interior edges double as the boundary of the
            # next panel (whose interpolant meets the same value only for
            # closed rules, where the boundary node is shared).
            ax.vlines(
                [x_curve[0], x_curve[-1]], 0, [y_curve[0], y_curve[-1]],
                color="steelblue", linewidth=0.8,
            )

        ax.hlines(0, result.a, result.b, color="steelblue", linewidth=0.8)

    def _format_axes(self, ax: plt.Axes, result: IntegrationResult):
        kind = "closed" if result.closed else "open"
        if isinstance(result, CompositeNewtonCotesResult):
            ax.set_title(
                f"{result.method_name} ({kind}, n={result.n}, "
                f"{result.subintervals} subintervals) on $[{result.a:.3g},{result.b:.3g}]$"
            )
        else:
            ax.set_title(f"{result.method_name} ({kind}, n={result.n}) on $[{result.a:.3g},{result.b:.3g}]$")
        ax.set_xlabel("$x$")
        ax.set_ylabel("$f(x)$")
        ax.legend(fontsize=9)
        ax.grid(True)
