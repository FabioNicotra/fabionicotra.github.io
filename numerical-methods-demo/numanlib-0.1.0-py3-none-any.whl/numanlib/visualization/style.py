SCIENTIFIC_STYLE = {
    "font.family": "serif",
    "text.usetex": True,

    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "axes.spines.top": False,
    "axes.spines.right": False,

    "lines.linewidth": 1.5,
    "lines.markersize": 6,

    "figure.dpi": 150,
    "savefig.dpi": 300,
}
