from functools import singledispatchmethod
import matplotlib.pyplot as plt
import numpy as np
from typing import Literal, Optional
from ..root_finding.results import SolverResult
from ..root_finding import BisectionResult, FixedPointResult
from .base import BasePlotter

PlotType = Literal["roots", "error", "convergence_ratio"]


class SolverPlotter(BasePlotter):
    _default_plot_type = "roots"
    def _plot_roots(self, result: SolverResult, ax: plt.Axes):
        self._draw_base_layer(result, ax)
        self._draw_method_details(result, ax)
        self._format_roots_axes(ax)
        return ax

    def _plot_error(self, result: SolverResult, ax: plt.Axes):
        iterations, errors = self._compute_errors(result)
        ax.semilogy(iterations, errors, marker="o")
        self._format_error_axes(ax)
        return ax

    def _plot_convergence_ratio(self, result: SolverResult, ax: plt.Axes, order: int = 1):
        iterations, errors = self._compute_errors(result)

        convergence_ratios = []
        for i in range(len(errors) - 1):
            if errors[i] > 1e-15:
                ratio = errors[i+1] / (errors[i] ** order)
                convergence_ratios.append(ratio)

        if convergence_ratios:
            ax.semilogy(iterations[:-1], convergence_ratios, marker="o", label=f"order={order}")

        self._format_convergence_axes(ax, order)
        return ax

    def _compute_errors(self, result):
        data = result.to_df()
        iterations = data.index[:-1]
        errors = np.abs(result.history - result.root)[:-1]
        return iterations, errors

    def _draw_base_layer(self, result: SolverResult, ax: plt.Axes):
        f = result.metadata.get("function")
        if not f:
            raise ValueError("Function not found in metadata.")
        data = result.to_df()
        x = self._get_x_values(result)

        ax.plot(x, f(x))
        iter_shown = 5
        p_i_filtered = data.loc[:iter_shown, "p_i"]
        fp_i_filtered = data.loc[:iter_shown, result.function_column]
        ax.scatter(p_i_filtered, fp_i_filtered, color="red", s=8, zorder=5)
        if result.root is not None:
            ax.scatter(result.root, f(result.root), color="red", s=20, zorder=10)

    def _get_x_values(self, result: SolverResult):
        data = result.to_df()
        x_min, x_max = data["p_i"].min(), data["p_i"].max()
        if result.root is not None:
            x_min, x_max = min(x_min, result.root), max(x_max, result.root)
        if "a_i" in data.columns:
            x_min = min(x_min, data["a_i"].min())
            x_max = max(x_max, data["b_i"].max())
        padding = 0.2*(x_max - x_min)
        x = np.linspace(x_min - padding, x_max + padding, 400)
        return x

    @singledispatchmethod
    def _draw_method_details(self, result: SolverResult, ax: plt.Axes):
        pass

    @_draw_method_details.register
    def _(self, result: BisectionResult, ax: plt.Axes):
        pass

    @_draw_method_details.register
    def _(self, result: FixedPointResult, ax: plt.Axes):
        x = self._get_x_values(result)
        ax.plot(x, x, color="black", label="$y=x$", linewidth=0.8)

        data = result.to_df()
        iter_shown = min(4, len(data) - 2)
        p_i_filtered = list(data.loc[:iter_shown, "p_i"])
        gp_i_filtered = list(data.loc[:iter_shown + 1, "g(p_i)"])
        ax.scatter(gp_i_filtered[:-1], gp_i_filtered[:-1], color="red", s=8, zorder=5)

        arrowprops = dict(arrowstyle="->", color="black", lw=0.8)
        p_0 = p_i_filtered[0]
        gp_0 = gp_i_filtered[0]
        y_min = ax.get_ylim()[0]
        ax.annotate("", xy=(p_0, gp_0), xytext=(p_0, y_min), arrowprops=arrowprops)

        for i in range(iter_shown + 1):
            p_i = p_i_filtered[i]
            gp_i = gp_i_filtered[i]
            ax.annotate("", xy=(gp_i, gp_i), xytext=(p_i, gp_i), arrowprops=arrowprops)
            ggp_i = gp_i_filtered[i + 1]
            ax.annotate("", xy=(gp_i, ggp_i), xytext=(gp_i, gp_i), arrowprops=arrowprops)

    def _format_roots_axes(self, ax: plt.Axes):
        if ax.get_ylim()[0] < 0 < ax.get_ylim()[1]:
            ax.spines["left"].set_position("zero")
        if ax.get_xlim()[0] < 0 < ax.get_xlim()[1]:
            ax.spines["bottom"].set_position("zero")

        ax.set_xlabel(r"$x$")
        ax.set_ylabel(r"$f\left( x \right)$")
        ax.grid(True)
        ax.set_title("Root Finding")

    def _format_error_axes(self, ax: plt.Axes):
        ax.set_xlabel("Iteration")
        ax.set_ylabel(r"$|p_n - \hat{p}|$")
        ax.grid(True, which="both")
        ax.set_title("Error plot")

    def _format_convergence_axes(self, ax, order):
        ylabel = fr"$\frac{{|e_{{n+1}}|}}{{|e_n|^{order}}}$" if order != 1 else r"$\frac{|e_{n+1}|}{|e_n|}$"
        ax.set_ylabel(ylabel)
        ax.set_xlabel("Iteration")
        ax.grid(True, which="both")
        ax.legend()
        ax.set_title("Convergence Ratio")
