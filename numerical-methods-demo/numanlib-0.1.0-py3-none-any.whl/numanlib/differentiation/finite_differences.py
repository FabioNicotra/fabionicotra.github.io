from dataclasses import dataclass, field
from fractions import Fraction
from math import factorial
from typing import Any, Callable, Dict, List, SupportsFloat, Tuple
import numpy as np
import pandas as pd
from numpy.typing import NDArray

from ..core.formatting import derivative_notation, signed_term
from ..interpolation import lagrange


def _node_label(offset: int) -> str:
    if offset == 0:
        return "x0"
    if abs(offset) == 1:
        return "x0+h" if offset > 0 else "x0-h"
    return f"x0{offset:+d}h"


def _rational_coefficients(
    weights: NDArray[np.float64], h: float, derivative_order: int
) -> List[Fraction]:
    return [Fraction(w * h**derivative_order).limit_denominator(10_000) for w in weights]


def _error_term(
    coeffs: List[Fraction], offsets: NDArray, derivative_order: int
) -> Tuple[int, Fraction]:
    n = len(offsets) - 1
    j = n + 1
    while j <= n + 6:
        leak = sum(c * Fraction(int(o)) ** j for c, o in zip(coeffs, offsets))
        if leak != 0:
            return j - derivative_order, leak / factorial(j)
        j += 1
    raise RuntimeError("Could not determine the truncation-error term for this stencil.")


FORWARD_DIFFERENCE = np.array([0, 1])
BACKWARD_DIFFERENCE = np.array([-1, 0])
THREE_POINT_MIDPOINT = np.array([-1, 0, 1])
THREE_POINT_ENDPOINT = np.array([0, 1, 2])
FIVE_POINT_MIDPOINT = np.array([-2, -1, 0, 1, 2])
FIVE_POINT_ENDPOINT = np.array([0, 1, 2, 3, 4])
SECOND_DERIVATIVE_MIDPOINT = np.array([-1, 0, 1])


@dataclass(frozen=True)
class FiniteDifferenceResult:
    value: float
    x0: float
    h: float
    derivative_order: int
    nodes: NDArray[np.float64]
    f_values: NDArray[np.float64]
    weights: NDArray[np.float64]
    error_order: int
    error_coefficient: Fraction
    method_name: str = "Finite Difference"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        deriv = derivative_notation(self.derivative_order)
        order_tag = "O(h)" if self.error_order == 1 else f"O(h^{self.error_order})"
        return (
            f"{self.method_name}: f{deriv}({self.x0}) ≈ {self.value} "
            f"({len(self.nodes)} points, h={self.h}, {order_tag})\n"
        )

    def to_df(self) -> pd.DataFrame:
        table = pd.DataFrame({
            "node": self.nodes,
            "f(node)": self.f_values,
            "weight": self.weights,
        })
        table.index.name = "i"
        return table

    def _error_expr(self, coeff: Fraction) -> str:
        k = self.derivative_order + self.error_order
        deriv = derivative_notation(k)
        h_term = "h" if self.error_order == 1 else f"h^{self.error_order}"
        return signed_term(coeff, f"{h_term}*f{deriv}(ξ)")

    def formula(self) -> str:
        offsets = np.round((self.nodes - self.x0) / self.h).astype(int)
        coeffs = _rational_coefficients(self.weights, self.h, self.derivative_order)

        terms = [
            signed_term(frac, f"f({_node_label(offset)})")
            for frac, offset in zip(coeffs, offsets)
            if frac != 0
        ]
        rhs = " + ".join(terms).replace("+ -", "- ")

        deriv = derivative_notation(self.derivative_order)
        denom = "h" if self.derivative_order == 1 else f"h^{self.derivative_order}"

        # exact = formula_value - error_coefficient * h^error_order * f^(k)(ξ)
        error_part = self._error_expr(-self.error_coefficient)
        return f"f{deriv}(x0) = (1/{denom}) * ({rhs}) + {error_part}".replace("+ -", "- ")

    def error_term(self) -> str:
        return f"error ≈ {self._error_expr(self.error_coefficient)}"

    def error_bound(self, M: SupportsFloat) -> float:
        return abs(float(self.error_coefficient)) * abs(self.h) ** self.error_order * float(M)

    def _abs_coefficient_sum(self) -> Fraction:
        coeffs = _rational_coefficients(self.weights, self.h, self.derivative_order)
        return sum(abs(c) for c in coeffs)

    def total_error_bound(self, M: SupportsFloat, epsilon: SupportsFloat) -> float:
        S = float(self._abs_coefficient_sum())
        round_off = float(epsilon) * S / abs(self.h) ** self.derivative_order
        return round_off + self.error_bound(M)

    def optimal_h(self, M: SupportsFloat, epsilon: SupportsFloat) -> float:
        S = float(self._abs_coefficient_sum())
        M, epsilon = float(M), float(epsilon)
        numerator = self.derivative_order * epsilon * S
        denominator = self.error_order * abs(float(self.error_coefficient)) * M
        return (numerator / denominator) ** (1 / (self.derivative_order + self.error_order))


def finite_difference(
    f: Callable[[SupportsFloat], SupportsFloat],
    x0: SupportsFloat,
    h: SupportsFloat,
    offsets: NDArray,
    derivative_order: int = 1,
) -> 'FiniteDifferenceResult':
    if not callable(f):
        raise TypeError("f must be a callable function.")
    try:
        x0 = float(x0)
        h = float(h)
    except (TypeError, ValueError):
        raise TypeError("x0 and h must be numeric values.")
    if h == 0:
        raise ValueError("h must be nonzero.")
    if not isinstance(derivative_order, int) or derivative_order <= 0:
        raise ValueError("derivative_order must be a positive integer.")

    offsets = np.array(offsets, dtype=float)
    if offsets.ndim != 1:
        raise ValueError("offsets must be a 1-D array.")
    if len(np.unique(offsets)) != len(offsets):
        raise ValueError("offsets must be distinct.")
    if len(offsets) <= derivative_order:
        raise ValueError(
            "offsets must contain more points than derivative_order to "
            "produce a nonzero derivative."
        )

    nodes = x0 + h * offsets
    f_values = np.array([f(node) for node in nodes], dtype=float)

    # Interpolate in the offset variable s = (x - x0) / h rather than in x
    # directly: the offsets are always small integers near the origin, so
    # the monomial expansion inside lagrange() stays well-conditioned
    # regardless of how large x0 or how small h is. Recover the x-derivative
    # via the chain rule: d^n f/dx^n(x0) = (1/h^n) * d^n g/ds^n(0).
    lag = lagrange(offsets, f_values)
    polynomial = lag.polynomial
    basis_polynomials = lag.metadata["basis_polynomials"]
    for _ in range(derivative_order):
        polynomial = polynomial.derivative()
        basis_polynomials = [basis.derivative() for basis in basis_polynomials]

    scale = 1.0 / h**derivative_order
    weights = np.array([basis(0.0) for basis in basis_polynomials]) * scale

    coeffs = _rational_coefficients(weights, h, derivative_order)
    offsets_int = np.round(offsets).astype(int)
    error_order, error_coefficient = _error_term(coeffs, offsets_int, derivative_order)

    return FiniteDifferenceResult(
        value=polynomial(0.0) * scale,
        x0=x0,
        h=h,
        derivative_order=derivative_order,
        nodes=nodes,
        f_values=f_values,
        weights=weights,
        error_order=error_order,
        error_coefficient=error_coefficient,
        metadata={"function": f},
    )
