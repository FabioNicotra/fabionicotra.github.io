from abc import ABC, abstractmethod
from typing import ClassVar, Optional, SupportsFloat, Type
import numpy as np
from numpy.typing import NDArray

from .base import IterativeResult, IterativeSolver


class StationaryIterativeSolver(IterativeSolver, ABC):
    _method_name: ClassVar[str]
    _result_cls: ClassVar[Type[IterativeResult]]

    @abstractmethod
    def _sweep(
        self,
        A: NDArray[np.float64],
        b: NDArray[np.float64],
        x_prev: NDArray[np.float64],
    ) -> NDArray[np.float64]:
        raise NotImplementedError

    def _run_solver(
        self,
        x0: NDArray[np.float64],
        criterion: str,
        tolerance: Optional[SupportsFloat],
        max_iterations: Optional[int],
    ) -> IterativeResult:
        self._apply_overrides(tolerance, max_iterations)
        n = self._A.shape[0]
        x_prev = np.array(x0, dtype=np.float64)
        history = [x_prev]

        # B&F Algorithms 7.1/7.2 require a_ii != 0 for each i; reorder rows if needed.
        nrow = list(range(n))
        for i in range(n):
            if self._A[nrow[i], i] == 0:
                p = next((k for k in range(i + 1, n) if self._A[nrow[k], i] != 0), None)
                if p is None:
                    return self._result_cls.failure(
                        method_name=self._method_name,
                        error_msg="Matrix cannot be reordered to eliminate a zero diagonal entry.",
                        history_list=history,
                    )
                nrow[i], nrow[p] = nrow[p], nrow[i]

        A = self._A[nrow]
        b = self._b[nrow]

        for _ in range(self.max_iterations):
            x = self._sweep(A, b, x_prev)
            history.append(x)

            if self._eval_stopping_condition(x, x_prev, criterion):
                return self._result_cls.success(
                    method_name=self._method_name,
                    history_list=history,
                    metadata={"criterion": criterion},
                )

            x_prev = x

        return self._result_cls.failure(
            method_name=self._method_name,
            error_msg=f"The method did not converge after {self.max_iterations} iterations.",
            history_list=history,
            metadata={"criterion": criterion},
        )
