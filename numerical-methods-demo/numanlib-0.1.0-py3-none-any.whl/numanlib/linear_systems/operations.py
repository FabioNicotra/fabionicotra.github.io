from dataclasses import dataclass
from typing import Sequence, Union
import numpy as np
from numpy.typing import NDArray


@dataclass(frozen=True)
class RowScaling:
    i: int
    coefficient: float

    def __post_init__(self) -> None:
        if self.coefficient == 0:
            raise ValueError("coefficient must be nonzero.")


@dataclass(frozen=True)
class RowAddition:
    i: int
    j: int
    coefficient: float


@dataclass(frozen=True)
class RowSwap:
    i: int
    j: int


_Op = Union[RowScaling, RowAddition, RowSwap]


def apply_operations(
    aug: NDArray[np.float64],
    operations: _Op | Sequence[_Op],
) -> NDArray[np.float64]:
    result = np.array(aug, dtype=float)
    ops: Sequence[_Op] = [operations] if isinstance(operations, (RowScaling, RowAddition, RowSwap)) else operations
    for op in ops:
        if isinstance(op, RowScaling):
            result[op.i] *= op.coefficient
        elif isinstance(op, RowAddition):
            result[op.i] += op.coefficient * result[op.j]
        elif isinstance(op, RowSwap):
            result[[op.i, op.j]] = result[[op.j, op.i]]
    return result
