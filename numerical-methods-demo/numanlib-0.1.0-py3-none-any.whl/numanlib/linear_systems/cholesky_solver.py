from dataclasses import dataclass
from typing import Optional
import numpy as np
from numpy.typing import NDArray

from .base import DirectResult, DirectSolver
from .cholesky_factorization import cholesky_factorization
from .substitution import backward_substitution, forward_substitution


@dataclass(frozen=True, repr=False)
class CholeskyResult(DirectResult):
    L: Optional[NDArray[np.float64]] = None

    def __post_init__(self) -> None:
        if self.solved and self.L is None:
            raise ValueError("L must be provided for a successful result")

    @classmethod
    def success(
        cls,
        solution: NDArray[np.float64],
        L: NDArray[np.float64],
        method_name: str = "Cholesky Factorization",
    ) -> 'CholeskyResult':
        return cls(solution=solution, solved=True, method_name=method_name, L=L)

    @classmethod
    def failure(
        cls,
        method_name: str = "Cholesky Factorization",
        error_msg: str = "",
    ) -> 'CholeskyResult':
        return cls(solution=None, solved=False, method_name=method_name, error_msg=error_msg)

_METHOD = "Cholesky Factorization"


class CholeskySolver(DirectSolver):
    def solve(self) -> 'CholeskyResult':
        try:
            factors = cholesky_factorization(self._A)
        except ValueError as e:
            return CholeskyResult.failure(method_name=_METHOD, error_msg=str(e))

        y = forward_substitution(factors.L, self._b)
        x = backward_substitution(factors.L.T, y)

        return CholeskyResult.success(solution=x, L=factors.L, method_name=_METHOD)
