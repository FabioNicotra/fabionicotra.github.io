from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, SupportsFloat
import numpy as np
import pandas as pd
from numpy.typing import NDArray


@dataclass(frozen=True)
class LinearSystemResult:
    solution: Optional[NDArray[np.float64]]
    method_name: str


@dataclass(frozen=True)
class DirectResult(LinearSystemResult):
    solved: bool
    error_msg: Optional[str] = None

    def __repr__(self) -> str:
        status = "succeeded" if self.solved else "failed"
        ret = f"{self.method_name} {status}\n"
        if self.solution is not None:
            ret += f"Solution: {self.solution}\n"
        if self.error_msg:
            ret += f"Error: {self.error_msg}\n"
        return ret

    @classmethod
    def success(
        cls,
        solution: NDArray[np.float64],
        method_name: str,
    ) -> 'DirectResult':
        return cls(solution=solution, method_name=method_name, solved=True)

    @classmethod
    def failure(
        cls,
        method_name: str,
        error_msg: str,
    ) -> 'DirectResult':
        return cls(solution=None, method_name=method_name, solved=False, error_msg=error_msg)


@dataclass(frozen=True)
class IterativeResult(LinearSystemResult):
    converged: bool
    iterations: int
    history: NDArray[np.float64]
    metadata: Dict[str, Any] = field(default_factory=dict)
    error_msg: Optional[str] = None

    def __repr__(self) -> str:
        status = "converged" if self.converged else "failed"
        ret = f"{self.method_name} {status} in {self.iterations} iterations\n"
        if self.solution is not None:
            ret += f"Solution: {self.solution}\n"
        if self.error_msg:
            ret += f"Error: {self.error_msg}\n"
        return ret

    @classmethod
    def success(
        cls,
        method_name: str,
        history_list: List[NDArray[np.float64]],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> 'IterativeResult':
        return cls(
            solution=history_list[-1], method_name=method_name, converged=True,
            iterations=len(history_list) - 1, history=np.array(history_list, dtype=np.float64),
            metadata=metadata or {},
        )

    @classmethod
    def failure(
        cls,
        method_name: str,
        error_msg: str,
        history_list: List[NDArray[np.float64]],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> 'IterativeResult':
        return cls(
            solution=None, method_name=method_name, converged=False,
            iterations=len(history_list) - 1, error_msg=error_msg,
            history=np.array(history_list, dtype=np.float64),
            metadata=metadata or {},
        )

    def to_df(self) -> pd.DataFrame:
        n = self.history.shape[1] if self.history.size else 0
        table = pd.DataFrame(self.history, columns=[f"x_{i + 1}" for i in range(n)])
        table.index.name = "iteration"
        return table


class LinearSystemSolver(ABC):
    def __init__(self, A: NDArray[np.float64], b: NDArray[np.float64]) -> None:
        self.A = A
        self.b = b
        if len(self.b) != self.A.shape[0]:
            raise ValueError("b must have the same length as the number of rows in A.")

    @property
    def A(self) -> NDArray[np.float64]:
        return self._A

    @A.setter
    def A(self, value: NDArray[np.float64]) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 2:
            raise ValueError("A must be a 2-D array.")
        if value.shape[0] != value.shape[1]:
            raise ValueError("A must be a square matrix.")
        self._A = value

    @property
    def b(self) -> NDArray[np.float64]:
        return self._b

    @b.setter
    def b(self, value: NDArray[np.float64]) -> None:
        value = np.array(value, dtype=float)
        if value.ndim != 1:
            raise ValueError("b must be a 1-D array.")
        self._b = value

    @abstractmethod
    def solve(self) -> 'LinearSystemResult':
        pass


class DirectSolver(LinearSystemSolver, ABC):
    @abstractmethod
    def solve(self) -> DirectResult:
        pass


class IterativeSolver(LinearSystemSolver, ABC):
    def __init__(
        self,
        A: NDArray[np.float64],
        b: NDArray[np.float64],
        tolerance: float = 1e-5,
        max_iterations: int = 100,
    ) -> None:
        super().__init__(A, b)
        self.tolerance = tolerance
        self.max_iterations = max_iterations

    @property
    def tolerance(self) -> float:
        return self._tolerance

    @tolerance.setter
    def tolerance(self, value: SupportsFloat) -> None:
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise TypeError("Tolerance must be a numeric value.")
        if value <= 0:
            raise ValueError("Tolerance must be a positive number.")
        self._tolerance = value

    @property
    def max_iterations(self) -> int:
        return self._max_iterations

    @max_iterations.setter
    def max_iterations(self, value: int) -> None:
        if not isinstance(value, int):
            raise TypeError("Max iterations must be an integer.")
        if value <= 0:
            raise ValueError("Max iterations must be a positive integer.")
        self._max_iterations = value

    def _apply_overrides(
        self,
        tolerance: Optional[SupportsFloat],
        max_iterations: Optional[int],
    ) -> None:
        if tolerance is not None:
            self.tolerance = tolerance
        if max_iterations is not None:
            self.max_iterations = max_iterations

    def _eval_stopping_condition(
        self,
        x: NDArray[np.float64],
        x_prev: NDArray[np.float64],
        criterion: str,
    ) -> bool:
        diff_norm = np.linalg.norm(x - x_prev, ord=np.inf)
        if criterion == "absolute":
            return diff_norm < self.tolerance
        elif criterion == "relative":
            x_norm = np.linalg.norm(x, ord=np.inf)
            if x_norm != 0:
                return diff_norm / x_norm < self.tolerance
            return diff_norm < self.tolerance
        else:
            raise ValueError("Invalid stopping criterion. Must be 'absolute' or 'relative'.")

    @abstractmethod
    def solve(self, x0: NDArray[np.float64]) -> IterativeResult:
        pass
