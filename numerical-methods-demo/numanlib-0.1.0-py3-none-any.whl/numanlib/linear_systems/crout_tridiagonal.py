import numpy as np
from numpy.typing import NDArray

from .base import DirectSolver, LinearSystemSolver
from .lu_factorization import LUFactors
from .lu_solver import LUResult


_METHOD = "Crout Factorization for Tridiagonal Systems"


def crout_tridiagonal_factorization(A: NDArray[np.float64]) -> LUFactors:
    # B&F §6.6 Algorithm 6.7 — Crout LU factorization for tridiagonal systems
    n = A.shape[0]
    sub = np.diag(A, -1)
    d = np.diag(A)
    sup = np.diag(A, 1)

    l = np.empty(n)
    u = np.empty(n - 1)

    l[0] = d[0]
    if l[0] == 0:
        raise ValueError("Factorization fails: l_11 = 0.")
    u[0] = sup[0] / l[0]

    for i in range(1, n):
        l[i] = d[i] - sub[i - 1] * u[i - 1]
        if l[i] == 0:
            raise ValueError(f"Factorization fails: l_{i + 1}{i + 1} = 0.")
        if i < n - 1:
            u[i] = sup[i] / l[i]

    L = np.diag(l) + np.diag(sub, -1)
    U = np.eye(n) + np.diag(u, 1)
    return LUFactors(L, U, np.eye(n))


class CroutTridiagonalSolver(DirectSolver):
    @property
    def A(self) -> NDArray[np.float64]:
        return self._A

    @A.setter
    def A(self, value: NDArray[np.float64]) -> None:
        LinearSystemSolver.A.fset(self, value)
        A = self._A
        if np.any(np.tril(A, -2)) or np.any(np.triu(A, 2)):
            raise ValueError("A must be a tridiagonal matrix.")

    def solve(self) -> LUResult:
        try:
            L, U, P = crout_tridiagonal_factorization(self._A)
        except ValueError as e:
            return LUResult.failure(method_name=_METHOD, error_msg=str(e))

        n = L.shape[0]
        l = np.diag(L)
        sub = np.diag(L, -1)
        u = np.diag(U, 1)

        # O(n) forward substitution: Lz = b
        z = np.empty(n)
        z[0] = self._b[0] / l[0]
        for i in range(1, n):
            z[i] = (self._b[i] - sub[i - 1] * z[i - 1]) / l[i]

        # O(n) backward substitution: Ux = z (U has unit diagonal)
        x = np.empty(n)
        x[-1] = z[-1]
        for i in range(n - 2, -1, -1):
            x[i] = z[i] - u[i] * x[i + 1]

        return LUResult.success(solution=x, L=L, U=U, P=P, method_name=_METHOD)
