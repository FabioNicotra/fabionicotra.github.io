import numpy as np
from numpy.typing import NDArray


def forward_substitution(L: NDArray[np.float64], b: NDArray[np.float64]) -> NDArray[np.float64]:
    """Solve Ly = b for y (L lower triangular)."""
    n = len(b)
    y = np.zeros(n)
    y[0] = b[0] / L[0, 0]
    for i in range(1, n):
        y[i] = (b[i] - np.dot(L[i, :i], y[:i])) / L[i, i]
    return y


def backward_substitution(U: NDArray[np.float64], b: NDArray[np.float64]) -> NDArray[np.float64]:
    """Solve Ux = b for x (U upper triangular)."""
    n = len(b)
    x = np.zeros(n)
    x[n - 1] = b[n - 1] / U[n - 1, n - 1]
    for i in range(n - 2, -1, -1):
        x[i] = (b[i] - np.dot(U[i, i + 1:n], x[i + 1:n])) / U[i, i]
    return x
