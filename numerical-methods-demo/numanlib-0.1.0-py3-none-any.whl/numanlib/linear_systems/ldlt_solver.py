from dataclasses import dataclass
from typing import Optional
import numpy as np
from numpy.typing import NDArray

from .base import DirectResult, DirectSolver
from .ldlt_factorization import ldlt_factorization
from .substitution import backward_substitution, forward_substitution


@dataclass(frozen=True, repr=False)
class LDLTResult(DirectResult):
    L: Optional[NDArray[np.float64]] = None
    D: Optional[NDArray[np.float64]] = None

    def __post_init__(self) -> None:
        if self.solved and (self.L is None or self.D is None):
            raise ValueError("L, D must be provided for a successful result")

    @classmethod
    def success(
        cls,
        solution: NDArray[np.float64],
        L: NDArray[np.float64],
        D: NDArray[np.float64],
        method_name: str = "LDL^T Factorization",
    ) -> 'LDLTResult':
        return cls(solution=solution, solved=True, method_name=method_name, L=L, D=D)

    @classmethod
    def failure(
        cls,
        method_name: str = "LDL^T Factorization",
        error_msg: str = "",
    ) -> 'LDLTResult':
        return cls(solution=None, solved=False, method_name=method_name, error_msg=error_msg)

_METHOD = "LDL^T Factorization"


class LDLTSolver(DirectSolver):
    def solve(self) -> 'LDLTResult':
        try:
            L, D = ldlt_factorization(self._A)
        except ValueError as e:
            return LDLTResult.failure(method_name=_METHOD, error_msg=str(e))

        y = forward_substitution(L, self._b)
        z = y / np.diag(D)
        x = backward_substitution(L.T, z)

        return LDLTResult.success(solution=x, L=L, D=D, method_name=_METHOD)
