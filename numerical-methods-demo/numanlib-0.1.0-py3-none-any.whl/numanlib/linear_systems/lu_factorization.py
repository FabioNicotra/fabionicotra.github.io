from typing import NamedTuple
import numpy as np
from numpy.typing import NDArray


class LUFactors(NamedTuple):
    L: NDArray[np.float64]
    U: NDArray[np.float64]
    P: NDArray[np.float64]


def lu_factorization(
    A: NDArray[np.float64],
    method: str = "doolittle",
) -> 'LUFactors':
    # B&F §6.5 Algorithm 6.4 with partial pivoting — PA = LU
    # method="doolittle": l_ii = 1  |  method="crout": u_ii = 1
    A = np.array(A, dtype=float)
    if A.ndim != 2:
        raise ValueError("A must be a 2-D array.")
    if A.shape[0] != A.shape[1]:
        raise ValueError("A must be a square matrix.")
    if method not in ("doolittle", "crout"):
        raise ValueError("method must be 'doolittle' or 'crout'.")

    n = A.shape[0]
    L = np.zeros((n, n))
    U = np.zeros((n, n))
    P = np.eye(n)
    W = A.copy()

    for i in range(n - 1):
        # Find first non-zero pivot in column i at or below row i
        p = next((k for k in range(i, n) if W[k, i] != 0), None)
        if p is None:
            raise ValueError("Factorization impossible: matrix is singular.")

        if p != i:
            W[[i, p]] = W[[p, i]]
            P[[i, p]] = P[[p, i]]
            if i > 0:
                L[[i, p], :i] = L[[p, i], :i]

        if method == "doolittle":
            L[i, i] = 1
            for j in range(i + 1, n):
                L[j, i] = W[j, i] / W[i, i]
                W[j] -= L[j, i] * W[i]
        else:  # crout
            L[i, i] = W[i, i]
            U[i, i] = 1
            for j in range(i + 1, n):
                mult = W[j, i] / W[i, i]
                L[j, i] = W[j, i]
                U[i, j] = W[i, j] / W[i, i]
                W[j] -= mult * W[i]

    # Last diagonal (Step 6)
    if W[n - 1, n - 1] == 0:
        raise ValueError("Factorization impossible: matrix is singular.")

    if method == "doolittle":
        L[n - 1, n - 1] = 1
        U[:] = np.triu(W)
    else:
        L[n - 1, n - 1] = W[n - 1, n - 1]
        U[n - 1, n - 1] = 1

    return LUFactors(L, U, P)
