from dataclasses import dataclass
from typing import Optional
import numpy as np
from numpy.typing import NDArray

from .base import DirectResult, DirectSolver
from .lu_factorization import lu_factorization
from .substitution import backward_substitution, forward_substitution


@dataclass(frozen=True, repr=False)
class LUResult(DirectResult):
    L: Optional[NDArray[np.float64]] = None
    U: Optional[NDArray[np.float64]] = None
    P: Optional[NDArray[np.float64]] = None

    def __post_init__(self) -> None:
        if self.solved and (self.L is None or self.U is None or self.P is None):
            raise ValueError("L, U, P must be provided for a successful result")

    @classmethod
    def success(
        cls,
        solution: NDArray[np.float64],
        L: NDArray[np.float64],
        U: NDArray[np.float64],
        P: NDArray[np.float64],
        method_name: str = "LU Factorization",
    ) -> 'LUResult':
        return cls(solution=solution, solved=True, method_name=method_name, L=L, U=U, P=P)

    @classmethod
    def failure(
        cls,
        method_name: str = "LU Factorization",
        error_msg: str = "",
    ) -> 'LUResult':
        return cls(solution=None, solved=False, method_name=method_name, error_msg=error_msg)

_METHOD = "LU Factorization"


class LUSolver(DirectSolver):
    def __init__(
        self,
        A: NDArray[np.float64],
        b: NDArray[np.float64],
        method: str = "doolittle",
    ) -> None:
        super().__init__(A, b)
        if method not in ("doolittle", "crout"):
            raise ValueError("method must be 'doolittle' or 'crout'.")
        self.method = method

    def solve(self) -> 'LUResult':
        try:
            L, U, P = lu_factorization(self._A, method=self.method)
        except ValueError as e:
            return LUResult.failure(method_name=_METHOD, error_msg=str(e))

        y = forward_substitution(L, P @ self._b)
        x = backward_substitution(U, y)

        return LUResult.success(solution=x, L=L, U=U, P=P, method_name=_METHOD)
