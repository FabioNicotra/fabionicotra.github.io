from dataclasses import dataclass
from typing import Optional, SupportsFloat
import numpy as np
from numpy.typing import NDArray

from .base import IterativeResult
from .stationary import StationaryIterativeSolver


@dataclass(frozen=True, repr=False)
class GaussSeidelResult(IterativeResult):
    pass


class GaussSeidelSolver(StationaryIterativeSolver):
    _method_name = "Gauss-Seidel"
    _result_cls = GaussSeidelResult

    def _sweep(
        self,
        A: NDArray[np.float64],
        b: NDArray[np.float64],
        x_prev: NDArray[np.float64],
    ) -> NDArray[np.float64]:
        n = A.shape[0]
        x = x_prev.copy()
        for i in range(n):
            x[i] = (-A[i, :] @ x + A[i, i] * x[i] + b[i]) / A[i, i]
        return x

    def solve(
        self,
        x0: NDArray[np.float64],
        criterion: str = "absolute",
        tolerance: Optional[SupportsFloat] = None,
        max_iterations: Optional[int] = None,
    ) -> 'GaussSeidelResult':
        return self._run_solver(x0, criterion, tolerance, max_iterations)
