from dataclasses import dataclass, field
from typing import Optional
import numpy as np
from numpy.typing import NDArray

from .base import LinearSystemResult
from .base import DirectResult, DirectSolver
from .operations import RowScaling, RowAddition, RowSwap, apply_operations
from .substitution import backward_substitution


def _fmt_aug(mat: NDArray) -> str:
    rows, cols = mat.shape
    formatted = [[f"{v:.4g}" for v in row] for row in mat]
    widths = [max(len(formatted[r][c]) for r in range(rows)) for c in range(cols)]
    lines = []
    for row in formatted:
        coeff = "  ".join(v.rjust(widths[c]) for c, v in enumerate(row[:-1]))
        lines.append(f"  [ {coeff} | {row[-1].rjust(widths[-1])} ]")
    return "\n".join(lines)


@dataclass(frozen=True, repr=False)
class GaussianEliminationResult(DirectResult):
    upper: Optional[NDArray[np.float64]] = None
    operations: tuple[RowScaling | RowAddition | RowSwap, ...] = field(default_factory=tuple)
    initial_aug: Optional[NDArray[np.float64]] = field(default=None, compare=False, repr=False)

    def __post_init__(self) -> None:
        if self.upper is None:
            raise ValueError("upper must be provided")

    def show_steps(self) -> None:
        if self.initial_aug is None:
            print("Step-by-step display not available for this method.")
            return
        aug = self.initial_aug.copy()
        print("Initial augmented matrix [A | b]:")
        print(_fmt_aug(aug))
        for op in self.operations:
            if isinstance(op, RowSwap):
                aug[[op.i, op.j]] = aug[[op.j, op.i]]
                print(f"\nR{op.i + 1} ↔ R{op.j + 1}:")
            elif isinstance(op, RowAddition):
                aug[op.i] += op.coefficient * aug[op.j]
                sign = "+" if op.coefficient >= 0 else "-"
                coeff_str = f"{abs(op.coefficient):.4g}·" if abs(op.coefficient) != 1 else ""
                print(f"\nR{op.i + 1} ← R{op.i + 1} {sign} {coeff_str}R{op.j + 1}:")
            print(_fmt_aug(aug))
        if self.solution is not None:
            print(f"\nSolution: {self.solution}")
        elif self.error_msg:
            print(f"\n{self.error_msg}")

    @classmethod
    def success(
        cls,
        solution: NDArray[np.float64],
        upper: NDArray[np.float64],
        operations: tuple,
        method_name: str = "Gaussian Elimination",
        initial_aug: Optional[NDArray[np.float64]] = None,
    ) -> 'GaussianEliminationResult':
        return cls(
            solution=solution, upper=upper, operations=operations,
            solved=True, method_name=method_name, initial_aug=initial_aug,
        )

    @classmethod
    def failure(
        cls,
        upper: NDArray[np.float64],
        operations: tuple,
        error_msg: str,
        method_name: str = "Gaussian Elimination",
        initial_aug: Optional[NDArray[np.float64]] = None,
    ) -> 'GaussianEliminationResult':
        return cls(
            solution=None, upper=upper, operations=operations,
            solved=False, error_msg=error_msg, method_name=method_name, initial_aug=initial_aug,
        )

_METHOD = "Gaussian Elimination"


class GaussianElimination(DirectSolver):
    def solve(self) -> 'GaussianEliminationResult':
        n = self._A.shape[0]
        aug = np.hstack((self._A, self._b.reshape(-1, 1)))
        initial_aug = aug.copy()
        ops: list[RowSwap | RowAddition] = []

        for i in range(n - 1):
            p = next((k for k in range(i, n) if aug[k, i] != 0), None)
            if p is None:
                return GaussianEliminationResult.failure(
                    upper=aug, operations=tuple(ops),
                    error_msg="Matrix is singular.", method_name=_METHOD,
                    initial_aug=initial_aug,
                )
            if p != i:
                op = RowSwap(i, p)
                aug = apply_operations(aug, op)
                ops.append(op)
            for j in range(i + 1, n):
                multiplier = -aug[j, i] / aug[i, i]
                if multiplier == 0:
                    continue
                op = RowAddition(j, i, multiplier)
                aug = apply_operations(aug, op)
                ops.append(op)

        if aug[n - 1, n - 1] == 0:
            return GaussianEliminationResult.failure(
                upper=aug, operations=tuple(ops),
                error_msg="Matrix is singular.", method_name=_METHOD,
                initial_aug=initial_aug,
            )

        return GaussianEliminationResult.success(
            solution=backward_substitution(aug[:, :n], aug[:, n]),
            upper=aug, operations=tuple(ops), method_name=_METHOD,
            initial_aug=initial_aug,
        )
