from typing import NamedTuple
import numpy as np
from numpy.typing import NDArray


class LDLTFactors(NamedTuple):
    L: NDArray[np.float64]
    D: NDArray[np.float64]


def ldlt_factorization(A: NDArray[np.float64]) -> 'LDLTFactors':
    # B&F §6.6 Algorithm 6.5 — A = LDL^T for positive definite A
    A = np.array(A, dtype=float)
    if A.ndim != 2:
        raise ValueError("A must be a 2-D array.")
    if A.shape[0] != A.shape[1]:
        raise ValueError("A must be a square matrix.")
    if not np.allclose(A, A.T):
        raise ValueError("A must be a symmetric matrix.")

    n = A.shape[0]
    L = np.eye(n)
    d = np.zeros(n)

    for i in range(n):
        v = np.array([L[i, j] * d[j] for j in range(i)])
        d[i] = A[i, i] - sum(L[i, j] * v[j] for j in range(i))
        if d[i] <= 0:
            raise ValueError("Matrix is not positive definite.")
        for j in range(i + 1, n):
            L[j, i] = (A[j, i] - sum(L[j, k] * v[k] for k in range(i))) / d[i]

    return LDLTFactors(L, np.diag(d))
