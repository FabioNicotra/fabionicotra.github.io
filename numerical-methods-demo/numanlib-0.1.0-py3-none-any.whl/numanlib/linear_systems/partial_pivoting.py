import numpy as np

from .gaussian_elimination import GaussianEliminationResult
from .base import DirectSolver
from .operations import RowSwap, RowAddition
from .substitution import backward_substitution

_METHOD = "Partial Pivoting"


class PartialPivoting(DirectSolver):
    def solve(self) -> GaussianEliminationResult:
        n = self._A.shape[0]
        aug = np.hstack((self._A, self._b.reshape(-1, 1)))
        # B&F §6.2 Algorithm 6.2 Step 1: initialize row pointer array
        nrow = list(range(n))
        ops: list[RowSwap | RowAddition] = []

        # B&F Step 2: elimination process
        for i in range(n - 1):
            # B&F Step 3: smallest p >= i with |a(NROW(p), i)| maximal
            p = max(range(i, n), key=lambda k: abs(aug[nrow[k], i]))

            # B&F Step 4
            if aug[nrow[p], i] == 0:
                return GaussianEliminationResult.failure(
                    upper=aug[nrow], operations=tuple(ops),
                    error_msg="Matrix is singular.", method_name=_METHOD,
                )

            # B&F Step 5: simulated row interchange via NROW
            if nrow[i] != nrow[p]:
                ops.append(RowSwap(i, p))
                nrow[i], nrow[p] = nrow[p], nrow[i]

            # B&F Steps 6–8: elimination
            for j in range(i + 1, n):
                multiplier = -aug[nrow[j], i] / aug[nrow[i], i]
                aug[nrow[j]] += multiplier * aug[nrow[i]]
                ops.append(RowAddition(nrow[j], nrow[i], multiplier))

        # B&F Step 9
        if aug[nrow[n - 1], n - 1] == 0:
            return GaussianEliminationResult.failure(
                upper=aug[nrow], operations=tuple(ops),
                error_msg="Matrix is singular.", method_name=_METHOD,
            )

        aug_ordered = aug[nrow]
        return GaussianEliminationResult.success(
            solution=backward_substitution(aug_ordered[:, :n], aug_ordered[:, n]),
            upper=aug_ordered, operations=tuple(ops), method_name=_METHOD,
        )
