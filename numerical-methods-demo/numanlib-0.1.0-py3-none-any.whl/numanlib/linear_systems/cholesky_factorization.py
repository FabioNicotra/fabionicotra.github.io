from typing import NamedTuple
import numpy as np
from numpy.typing import NDArray


class CholeskyFactors(NamedTuple):
    L: NDArray[np.float64]


def cholesky_factorization(A: NDArray[np.float64]) -> 'CholeskyFactors':
    # B&F §6.6 Algorithm 6.6 — A = LL^T for positive definite A
    A = np.array(A, dtype=float)
    if A.ndim != 2:
        raise ValueError("A must be a 2-D array.")
    if A.shape[0] != A.shape[1]:
        raise ValueError("A must be a square matrix.")
    if not np.allclose(A, A.T):
        raise ValueError("A must be a symmetric matrix.")

    n = A.shape[0]
    L = np.zeros((n, n))

    radicand = A[0, 0]
    if radicand <= 0:
        raise ValueError("Matrix is not positive definite.")
    L[0, 0] = np.sqrt(radicand)

    for j in range(1, n):
        L[j, 0] = A[j, 0] / L[0, 0]

    for i in range(1, n - 1):
        radicand = A[i, i] - np.dot(L[i, :i], L[i, :i])
        if radicand <= 0:
            raise ValueError("Matrix is not positive definite.")
        L[i, i] = np.sqrt(radicand)
        for j in range(i + 1, n):
            L[j, i] = (A[j, i] - np.dot(L[j, :i], L[i, :i])) / L[i, i]

    radicand = A[n - 1, n - 1] - np.dot(L[n - 1, :n - 1], L[n - 1, :n - 1])
    if radicand <= 0:
        raise ValueError("Matrix is not positive definite.")
    L[n - 1, n - 1] = np.sqrt(radicand)

    return CholeskyFactors(L)


def is_positive_definite(A: NDArray[np.float64]) -> bool:
    A = np.array(A, dtype=float)
    if A.ndim != 2 or A.shape[0] != A.shape[1]:
        return False
    if not np.allclose(A, A.T):
        return False
    try:
        cholesky_factorization(A)
        return True
    except ValueError:
        return False
