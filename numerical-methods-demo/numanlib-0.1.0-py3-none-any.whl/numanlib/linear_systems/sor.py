from dataclasses import dataclass, replace
from typing import Optional, SupportsFloat
import numpy as np
from numpy.typing import NDArray

from .base import IterativeResult
from .stationary import StationaryIterativeSolver


@dataclass(frozen=True, repr=False)
class SORResult(IterativeResult):
    pass


class SORSolver(StationaryIterativeSolver):
    _method_name = "SOR"
    _result_cls = SORResult

    def __init__(
        self,
        A: NDArray[np.float64],
        b: NDArray[np.float64],
        omega: SupportsFloat,
        tolerance: float = 1e-5,
        max_iterations: int = 100,
    ) -> None:
        super().__init__(A, b, tolerance, max_iterations)
        self.omega = omega

    @property
    def omega(self) -> float:
        return self._omega

    @omega.setter
    def omega(self, value: SupportsFloat) -> None:
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise TypeError("Omega must be a numeric value.")
        if not (0 < value < 2):
            raise ValueError("Omega must be in the interval (0, 2) for SOR to converge (Kahan's theorem).")
        self._omega = value

    def _sweep(
        self,
        A: NDArray[np.float64],
        b: NDArray[np.float64],
        x_prev: NDArray[np.float64],
    ) -> NDArray[np.float64]:
        n = A.shape[0]
        x = x_prev.copy()
        for i in range(n):
            gauss_seidel_update = (-A[i, :] @ x + A[i, i] * x[i] + b[i]) / A[i, i]
            x[i] = (1 - self.omega) * x_prev[i] + self.omega * gauss_seidel_update
        return x

    def solve(
        self,
        x0: NDArray[np.float64],
        criterion: str = "absolute",
        tolerance: Optional[SupportsFloat] = None,
        max_iterations: Optional[int] = None,
    ) -> 'SORResult':
        result = self._run_solver(x0, criterion, tolerance, max_iterations)
        return replace(result, metadata={**result.metadata, "omega": self.omega})
